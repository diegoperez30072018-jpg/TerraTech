/* TerraTech — capa de datos y sesiones
   Firebase (servidor, sincroniza entre teléfonos) o modo local (solo este teléfono).
   © 2026 Juan Diego Pérez Lopez. Todos los derechos reservados. */

const COLLECTIONS = ['lotes', 'gastos', 'ingresos', 'facturas', 'eventos', 'pqr', 'cultivosPropios', 'trabajadores', 'trabajos', 'pagos'];
const FB_VERSION = '10.12.2';

const Store = (() => {
  let mode = 'local';          // 'firebase' | 'local'
  let fb = null, auth = null, db = null;
  let user = null;             // { uid, email, name }
  let profile = {};
  const cache = {};
  const unsubs = [];
  const listeners = new Set();
  let userCb = () => {};

  const ls = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { console.warn(e); return false; } },
    del(k) { try { localStorage.removeItem(k); } catch {} }
  };

  const configured = () => {
    const c = window.TERRATECH_FIREBASE || {};
    return c.apiKey && !String(c.apiKey).includes('PEGA_AQUI') && c.projectId && !String(c.projectId).includes('PEGA_AQUI');
  };

  const loadScript = (src) => new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('No se pudo cargar ' + src));
    document.head.appendChild(s);
  });

  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  async function sha256(text) {
    try {
      const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
      return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
    } catch {
      let h = 5381; for (const ch of text) h = ((h << 5) + h + ch.charCodeAt(0)) >>> 0; return 'x' + h.toString(16);
    }
  }

  function emit() { listeners.forEach(fn => { try { fn(); } catch (e) { console.error(e); } }); }

  // ---------- Inicio ----------
  async function init() {
    if (configured()) {
      try {
        const base = `https://www.gstatic.com/firebasejs/${FB_VERSION}/`;
        await loadScript(base + 'firebase-app-compat.js');
        await Promise.all([loadScript(base + 'firebase-auth-compat.js'), loadScript(base + 'firebase-firestore-compat.js')]);
        fb = firebase.initializeApp(window.TERRATECH_FIREBASE);
        auth = firebase.auth();
        db = firebase.firestore();
        try { await db.enablePersistence({ synchronizeTabs: true }); } catch (e) { console.warn('Persistencia offline:', e.code); }
        await auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL);
        mode = 'firebase';
        auth.onAuthStateChanged(async (u) => {
          if (u) { user = { uid: u.uid, email: u.email, name: u.displayName || u.email.split('@')[0], verified: u.emailVerified }; await attach(); }
          else { detach(); user = null; }
          userCb(user);
        });
        return mode;
      } catch (e) {
        console.warn('Firebase no disponible, usando modo local', e);
      }
    }
    mode = 'local';
    const s = ls.get('tt_session', null);
    if (s) { user = s; await attach(); }
    setTimeout(() => userCb(user), 0);
    return mode;
  }

  // ---------- Sesión ----------
  function onUser(cb) { userCb = cb; }

  async function register(name, email, pass) {
    email = email.trim().toLowerCase();
    if (mode === 'firebase') {
      const cred = await auth.createUserWithEmailAndPassword(email, pass);
      await cred.user.updateProfile({ displayName: name });
      try { await cred.user.sendEmailVerification(); } catch {}
      await db.collection('usuarios').doc(cred.user.uid).set({ nombre: name, correo: email, creado: new Date().toISOString(), app: 'TerraTech' }, { merge: true });
      user = { uid: cred.user.uid, email, name };
      return user;
    }
    const users = ls.get('tt_users', {});
    if (users[email]) throw { code: 'auth/email-already-in-use' };
    const id = uid();
    users[email] = { uid: id, name, hash: await sha256(email + '|' + pass), creado: new Date().toISOString() };
    ls.set('tt_users', users);
    user = { uid: id, email, name };
    ls.set('tt_session', user);
    await attach(); userCb(user);
    return user;
  }

  async function login(email, pass) {
    email = email.trim().toLowerCase();
    if (mode === 'firebase') { await auth.signInWithEmailAndPassword(email, pass); return; }
    const users = ls.get('tt_users', {});
    const u = users[email];
    if (!u) throw { code: 'auth/user-not-found' };
    if (u.hash !== await sha256(email + '|' + pass)) throw { code: 'auth/wrong-password' };
    user = { uid: u.uid, email, name: u.name };
    ls.set('tt_session', user);
    await attach(); userCb(user);
  }

  async function resetPassword(email) {
    email = email.trim().toLowerCase();
    if (mode === 'firebase') return auth.sendPasswordResetEmail(email);
    throw { code: 'local/reset' };
  }

  async function changePassword(oldPass, newPass) {
    if (mode === 'firebase') {
      const cred = firebase.auth.EmailAuthProvider.credential(user.email, oldPass);
      await auth.currentUser.reauthenticateWithCredential(cred);
      return auth.currentUser.updatePassword(newPass);
    }
    const users = ls.get('tt_users', {});
    const u = users[user.email];
    if (u.hash !== await sha256(user.email + '|' + oldPass)) throw { code: 'auth/wrong-password' };
    u.hash = await sha256(user.email + '|' + newPass); ls.set('tt_users', users);
  }

  async function logout() {
    detach();
    if (mode === 'firebase') { await auth.signOut(); return; }
    ls.del('tt_session'); user = null; userCb(null);
  }

  // Correos guardados para iniciar sesión rápido
  const savedEmails = {
    list: () => ls.get('tt_saved_emails', []),
    add(email) { email = email.trim().toLowerCase(); const l = savedEmails.list().filter(e => e !== email); l.unshift(email); ls.set('tt_saved_emails', l.slice(0, 6)); },
    remove(email) { ls.set('tt_saved_emails', savedEmails.list().filter(e => e !== email)); }
  };

  // ---------- Datos ----------
  const key = (col) => `tt_${user.uid}_${col}`;

  async function attach() {
    detach();
    COLLECTIONS.forEach(c => cache[c] = []);
    if (mode === 'firebase') {
      const base = db.collection('usuarios').doc(user.uid);
      unsubs.push(base.onSnapshot(d => { profile = d.data() || {}; emit(); }));
      COLLECTIONS.forEach(col => {
        unsubs.push(base.collection(col).onSnapshot(snap => {
          cache[col] = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          emit();
        }, err => console.warn(col, err)));
      });
    } else {
      COLLECTIONS.forEach(col => cache[col] = ls.get(key(col), []));
      profile = ls.get(`tt_${user.uid}_perfil`, {});
    }
    emit();
  }

  function detach() { while (unsubs.length) { try { unsubs.pop()(); } catch {} } }

  function list(col) { return cache[col] || []; }
  function get(col, id) { return list(col).find(x => x.id === id); }

  async function add(col, obj) {
    const id = obj.id || uid();
    const data = { ...obj, id, creado: obj.creado || new Date().toISOString() };
    if (mode === 'firebase') {
      cache[col] = [...list(col).filter(x => x.id !== id), data]; emit();
      await db.collection('usuarios').doc(user.uid).collection(col).doc(id).set(clean(data));
      if (col === 'pqr') { try { await db.collection('pqr').doc(id).set(clean({ ...data, uid: user.uid, correo: user.email, nombre: user.name })); } catch (e) { console.warn(e); } }
    } else {
      cache[col] = [...list(col).filter(x => x.id !== id), data];
      if (!ls.set(key(col), cache[col])) throw { code: 'local/quota' };
      emit();
    }
    return data;
  }

  async function update(col, id, patch) {
    const cur = get(col, id) || { id };
    const data = { ...cur, ...patch, id, modificado: new Date().toISOString() };
    return add(col, data);
  }

  async function remove(col, id) {
    cache[col] = list(col).filter(x => x.id !== id);
    if (mode === 'firebase') { emit(); await db.collection('usuarios').doc(user.uid).collection(col).doc(id).delete(); }
    else { ls.set(key(col), cache[col]); emit(); }
  }

  async function saveProfile(p) {
    profile = { ...profile, ...p };
    if (mode === 'firebase') {
      await db.collection('usuarios').doc(user.uid).set(clean(profile), { merge: true });
      if (p.nombre && auth.currentUser) { await auth.currentUser.updateProfile({ displayName: p.nombre }); user.name = p.nombre; }
    } else {
      ls.set(`tt_${user.uid}_perfil`, profile);
      if (p.nombre) { user.name = p.nombre; ls.set('tt_session', user); const us = ls.get('tt_users', {}); if (us[user.email]) { us[user.email].name = p.nombre; ls.set('tt_users', us); } }
    }
    emit();
  }

  function clean(o) { return JSON.parse(JSON.stringify(o, (k, v) => v === undefined ? null : v)); }

  function exportAll() {
    const out = { app: 'TerraTech', version: 1, exportado: new Date().toISOString(), usuario: user.email, perfil: profile };
    COLLECTIONS.forEach(c => out[c] = list(c));
    return out;
  }

  async function importAll(data) {
    if (!data || data.app !== 'TerraTech') throw new Error('El archivo no es un respaldo de TerraTech');
    let n = 0;
    for (const col of COLLECTIONS) for (const item of (data[col] || [])) { await add(col, item); n++; }
    if (data.perfil) await saveProfile(data.perfil);
    return n;
  }

  return {
    init, onUser, register, login, logout, resetPassword, changePassword, savedEmails,
    list, get, add, update, remove, saveProfile, exportAll, importAll,
    subscribe: (fn) => { listeners.add(fn); return () => listeners.delete(fn); },
    get mode() { return mode; }, get user() { return user; }, get profile() { return profile; }
  };
})();
