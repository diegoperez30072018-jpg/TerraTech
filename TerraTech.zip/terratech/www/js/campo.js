/* TerraTech — trabajadores, pagos, ubicación e informe diario
   © 2026 Juan Diego Pérez Lopez. Todos los derechos reservados. */

/* ---------------- Hora y ubicación ---------------- */
const nowTime = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const fmtTime = (t) => { if (!t) return ''; const [h, m] = t.split(':').map(Number); const ap = h < 12 ? 'a. m.' : 'p. m.'; return `${((h + 11) % 12) + 1}:${pad(m)} ${ap}`; };
const mapsLink = (u) => u && u.lat != null ? `https://www.google.com/maps?q=${u.lat},${u.lng}` : null;
const placeText = (x) => { const u = x?.ubicacion; if (!x?.lugar && !u?.lat) return ''; return `📍 ${esc(x.lugar || '')}${u?.lat != null ? `${x.lugar ? ' · ' : ''}<a href="${mapsLink(u)}" target="_blank" rel="noopener" onclick="event.stopPropagation()">ver mapa</a>` : ''}`; };

function getLocation() {
  return new Promise((res, rej) => {
    if (!navigator.geolocation) return rej(new Error('Este dispositivo no permite ubicación'));
    navigator.geolocation.getCurrentPosition(
      p => res({ lat: +p.coords.latitude.toFixed(6), lng: +p.coords.longitude.toFixed(6), precision: Math.round(p.coords.accuracy), hora: new Date().toISOString() }),
      e => rej(new Error(e.code === 1 ? 'Permiso de ubicación negado. Actívalo en los ajustes del teléfono o escribe el lugar.' : 'No se pudo obtener la ubicación. Escribe el lugar a mano.')),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 });
  });
}

// Campo de lugar + GPS reutilizable
function locFieldHTML(px, rec = {}) {
  const u = rec.ubicacion;
  return `<div class="field"><label>Lugar</label>
    <input id="${px}Lug" value="${esc(rec.lugar || '')}" placeholder="Ej: Finca La Esperanza, plaza de mercado, acopio" list="${px}LugL">
    <datalist id="${px}LugL">${[...new Set([...Store.list('pagos'), ...Store.list('ingresos'), ...Store.list('trabajos')].map(x => x.lugar).filter(Boolean))].slice(0, 30).map(x => `<option value="${esc(x)}">`).join('')}</datalist>
    <div class="loc-row"><button type="button" class="btn sm" id="${px}Gps">📍 Usar mi ubicación actual</button><span class="loc-info" id="${px}LocI">${u?.lat != null ? `${u.lat}, ${u.lng} (±${u.precision || '?'} m) · <a href="${mapsLink(u)}" target="_blank" rel="noopener">mapa</a>` : 'Sin coordenadas'}</span></div></div>`;
}
function bindLoc(px, rec = {}) {
  let ub = rec.ubicacion || null;
  const btn = $('#' + px + 'Gps');
  btn.onclick = async () => {
    btn.disabled = true; btn.textContent = 'Buscando señal GPS…';
    try {
      ub = await getLocation();
      $('#' + px + 'LocI').innerHTML = `${ub.lat}, ${ub.lng} (±${ub.precision} m) · <a href="${mapsLink(ub)}" target="_blank" rel="noopener">mapa</a>`;
      toast('Ubicación guardada 📍');
    } catch (e) { toast(e.message, true); }
    btn.disabled = false; btn.textContent = '📍 Actualizar ubicación';
  };
  return () => ({ lugar: $('#' + px + 'Lug').value.trim(), ubicacion: ub });
}

/* ---------------- Trabajadores: cálculos ---------------- */
const worker = (id) => Store.get('trabajadores', id);
const workerName = (id) => worker(id)?.nombre || 'Trabajador';
function workerBalance(id) {
  const tr = Store.list('trabajos').filter(t => t.trabajador === id);
  const pg = Store.list('pagos').filter(p => p.trabajador === id && p.concepto !== 'Bonificación');
  const devengado = sum(tr, t => t.total), pagado = sum(pg, p => p.monto);
  return { devengado, pagado, saldo: devengado - pagado, pendientes: tr.filter(t => !t.pagado) };
}
const payDescr = (p) => `${p.concepto}${p.trabajos?.length ? ` · ${p.trabajos.length} registro${p.trabajos.length > 1 ? 's' : ''}` : ''}`;

function trabajoItem(t) {
  return `<div class="item" data-trabajo="${t.id}"><div class="ic" style="background:#8C5A2B22">👨‍🌾</div>
    <div class="mid"><b>${esc(workerName(t.trabajador))} · ${esc(t.labor)}</b><small>${qty(t.cantidad)} ${esc(t.unidad)} · ${esc(loteName(t.lote))}${t.hora ? ' · ' + fmtTime(t.hora) : ''}</small>${t.lugar || t.ubicacion ? `<small>${placeText(t)}</small>` : ''}</div>
    <div class="amt">${money(t.total)}<small>${fmtDate(t.fecha)} · ${t.pagado ? '<span class="tag">Pagado</span>' : '<span class="tag red">Debe</span>'}</small></div></div>`;
}
function pagoItem(p) {
  return `<div class="item" data-pago="${p.id}"><div class="ic" style="background:#1F7AB822">💵</div>
    <div class="mid"><b>${esc(workerName(p.trabajador))}</b><small>${esc(payDescr(p))} · ${esc(p.metodo || '')}${p.hora ? ' · ' + fmtTime(p.hora) : ''}</small>${p.lugar || p.ubicacion ? `<small>${placeText(p)}</small>` : ''}</div>
    <div class="amt neg">-${money(p.monto)}<small>${fmtDate(p.fecha)}</small></div></div>`;
}
function bindWorkItems(root) {
  $$('[data-trabajo]', root).forEach(x => x.onclick = () => Forms.trabajo(Store.get('trabajos', x.dataset.trabajo)));
  $$('[data-pago]', root).forEach(x => x.onclick = () => Forms.comprobante(Store.get('pagos', x.dataset.pago)));
  $$('[data-worker]', root).forEach(x => x.onclick = () => go('trabajador', { id: x.dataset.worker }));
}

/* ---------------- Vistas de trabajadores ---------------- */
Views.trabajadores = (el) => {
  const W = Store.list('trabajadores').sort((a, b) => (a.activo === false) - (b.activo === false) || a.nombre.localeCompare(b.nombre));
  const m = state.month;
  const deuda = sum(W, w => Math.max(0, workerBalance(w.id).saldo));
  const pagMes = sum(Store.list('pagos').filter(p => sameMonth(p.fecha, m)), p => p.monto);
  const jorMes = sum(Store.list('trabajos').filter(t => sameMonth(t.fecha, m) && /jornal|día/.test(t.unidad)), t => t.unidad === 'medio jornal' ? num(t.cantidad) / 2 : t.cantidad);
  const recent = [...Store.list('pagos').map(p => ({ ...p, _k: 'p' })), ...Store.list('trabajos').map(t => ({ ...t, _k: 't' }))].sort((a, b) => ((b.fecha + (b.hora || '')) + b.creado).localeCompare((a.fecha + (a.hora || '')) + a.creado)).slice(0, 8);
  el.innerHTML = `
    <div class="hero"><div class="hi">👨‍🌾 Trabajadores · ${monthLabel(m)}</div>
      <div class="bal-label">Total por pagar</div><div class="bal">${money(deuda)}</div>
      <div class="row"><div class="pill"><small>Pagado este mes</small><b>${money(pagMes)}</b></div><div class="pill"><small>Jornales del mes</small><b>${qty(jorMes)}</b></div></div></div>
    <div class="btn-row" style="margin-bottom:14px"><button class="btn primary sm" id="wJ">📝 Registrar trabajo</button><button class="btn soil sm" id="wP">💵 Pagar</button><button class="btn sm" id="wN">➕ Trabajador</button></div>
    ${W.length ? `<div class="section-title">Equipo de trabajo</div><div class="card" style="padding:4px 14px"><div class="list">${W.map(w => { const b = workerBalance(w.id); return `<div class="item" data-worker="${w.id}"><div class="ic avatar">${esc(w.nombre.slice(0, 1).toUpperCase())}</div>
      <div class="mid"><b>${esc(w.nombre)}${w.activo === false ? ' <span class="tag soil">Inactivo</span>' : ''}</b><small>${esc(w.labor || w.formaPago)} · ${money(w.valor)} / ${esc(unitOfPay(w.formaPago))}</small></div>
      <div class="amt ${b.saldo > 0 ? 'neg' : 'pos'}">${b.saldo > 0 ? 'Debe ' + money(b.saldo) : b.saldo < 0 ? 'A favor ' + money(-b.saldo) : 'Al día'}<small>${b.pendientes.length} pendiente${b.pendientes.length === 1 ? '' : 's'}</small></div></div>`; }).join('')}</div></div>`
      : emptyBox('👨‍🌾', 'Aún no tienes trabajadores', 'Agrégalos para registrar jornales, destajos y pagos con fecha, hora y lugar.', 'Agregar trabajador', 'trabajador')}
    ${recent.length ? `<div class="section-title">Movimientos recientes</div><div class="card" style="padding:4px 14px"><div class="list">${recent.map(x => x._k === 'p' ? pagoItem(x) : trabajoItem(x)).join('')}</div></div>` : ''}`;
  $('#wJ', el).onclick = () => Forms.trabajo();
  $('#wP', el).onclick = () => Forms.pago();
  $('#wN', el).onclick = () => Forms.trabajador();
  $$('[data-empty]', el).forEach(b => b.onclick = () => Forms.trabajador());
  bindWorkItems(el);
};
const unitOfPay = (f) => ({ 'Jornal': 'jornal', 'Destajo por kg': 'kg', 'Destajo por unidad': 'unidad', 'Por hora': 'hora', 'Contrato': 'contrato', 'Mensual': 'mes' }[f] || 'jornal');

Views.trabajador = (el) => {
  const w = worker(state.params.id);
  if (!w) { el.innerHTML = emptyBox('🤷', 'Trabajador no encontrado', '', '', ''); return; }
  const b = workerBalance(w.id);
  const hist = [...Store.list('pagos').filter(p => p.trabajador === w.id).map(p => ({ ...p, _k: 'p' })), ...Store.list('trabajos').filter(t => t.trabajador === w.id).map(t => ({ ...t, _k: 't' }))].sort((a, c) => ((c.fecha + (c.hora || '')) + c.creado).localeCompare((a.fecha + (a.hora || '')) + a.creado));
  el.innerHTML = `
    <div class="hero"><div class="hi" style="display:flex;gap:12px;align-items:center"><span class="avatar big">${esc(w.nombre.slice(0, 1).toUpperCase())}</span><div><b style="font-size:17px">${esc(w.nombre)}</b><br><small>${esc(w.labor || '')}${w.telefono ? ' · ' + esc(w.telefono) : ''}</small></div></div>
      <div class="bal-label">${b.saldo >= 0 ? 'Saldo por pagar' : 'Saldo a favor (adelantos)'}</div><div class="bal">${money(Math.abs(b.saldo))}</div>
      <div class="row"><div class="pill"><small>Total trabajado</small><b>${money(b.devengado)}</b></div><div class="pill"><small>Total pagado</small><b>${money(b.pagado)}</b></div></div></div>
    <div class="card"><div class="lot-stats" style="margin:0;padding:0;border:0;grid-template-columns:repeat(2,1fr);row-gap:12px">
      <div><small>Forma de pago</small><b>${esc(w.formaPago)}</b></div><div><small>Valor</small><b>${money(w.valor)} / ${esc(unitOfPay(w.formaPago))}</b></div>
      <div><small>Documento</small><b>${esc(w.documento || '—')}</b></div><div><small>Desde</small><b>${w.ingreso ? fmtDate(w.ingreso) : '—'}</b></div></div>
      ${w.notas ? `<p style="color:var(--muted);font-size:13.5px;margin:12px 0 0">📝 ${esc(w.notas)}</p>` : ''}</div>
    <div class="btn-row" style="margin-bottom:14px"><button class="btn primary sm" id="tJ">📝 Trabajo</button><button class="btn soil sm" id="tP">💵 Pagar${b.saldo > 0 ? ' ' + moneyShort(b.saldo) : ''}</button><button class="btn sm" id="tE">${ICON.edit}</button></div>
    <div class="section-title">Historial</div>
    <div class="card" style="padding:4px 14px">${hist.length ? `<div class="list">${hist.map(x => x._k === 'p' ? pagoItem(x) : trabajoItem(x)).join('')}</div>` : '<div class="empty" style="padding:16px"><p>Sin registros todavía.</p></div>'}</div>`;
  $('#tJ', el).onclick = () => Forms.trabajo(null, { trabajador: w.id });
  $('#tP', el).onclick = () => Forms.pago(null, { trabajador: w.id });
  $('#tE', el).onclick = () => Forms.trabajador(w);
  bindWorkItems(el);
};

/* ---------------- Formularios de trabajadores ---------------- */
Forms.trabajador = (w) => {
  const d = w || { formaPago: 'Jornal', valor: 60000, activo: true, ingreso: today() };
  Sheet.open(w ? 'Editar trabajador' : 'Nuevo trabajador', `
    <div class="field"><label>Nombre completo</label><input id="wNom" value="${esc(d.nombre || '')}" placeholder="Ej: Carlos Rodríguez"></div>
    <div class="grid2"><div class="field"><label>Cédula</label><input id="wDoc" inputmode="numeric" value="${esc(d.documento || '')}"></div><div class="field"><label>Celular</label><input id="wTel" type="tel" value="${esc(d.telefono || '')}"></div></div>
    <div class="field"><label>Labor principal</label><select id="wLab">${opts(WORK_LABORS, d.labor || WORK_LABORS[0])}</select></div>
    <div class="grid2"><div class="field"><label>Forma de pago</label><select id="wFP">${opts(WORKER_PAY_TYPES, d.formaPago)}</select></div><div class="field"><label>Valor <span id="wUnit">/ ${unitOfPay(d.formaPago)}</span></label><input id="wVal" type="number" inputmode="numeric" value="${esc(d.valor || '')}"></div></div>
    <div class="grid2"><div class="field"><label>Fecha de ingreso</label><input id="wIng" type="date" value="${esc(d.ingreso || '')}"></div><div class="field"><label>Estado</label><select id="wAct"><option value="1" ${d.activo !== false ? 'selected' : ''}>Activo</option><option value="0" ${d.activo === false ? 'selected' : ''}>Inactivo</option></select></div></div>
    <div class="field"><label>Notas</label><textarea id="wNot" placeholder="EPS, contacto de emergencia, observaciones">${esc(d.notas || '')}</textarea></div>
    <button class="btn primary block" id="wSave">${w ? 'Guardar cambios' : 'Agregar trabajador'}</button>
    ${w ? '<button class="btn danger block" id="wDel" style="margin-top:10px">Eliminar trabajador</button>' : ''}`, b => {
    $('#wFP', b).onchange = () => $('#wUnit').textContent = '/ ' + unitOfPay($('#wFP').value);
    $('#wSave', b).onclick = async () => {
      const data = { nombre: $('#wNom').value.trim(), documento: $('#wDoc').value.trim(), telefono: $('#wTel').value.trim(), labor: $('#wLab').value, formaPago: $('#wFP').value, valor: num($('#wVal').value), ingreso: $('#wIng').value, activo: $('#wAct').value === '1', notas: $('#wNot').value.trim() };
      if (!data.nombre) return toast('Escribe el nombre del trabajador', true);
      const r = w ? await Store.update('trabajadores', w.id, data) : await Store.add('trabajadores', data);
      toast(w ? 'Trabajador actualizado' : 'Trabajador agregado'); Sheet.close();
      w ? render() : go('trabajador', { id: r.id });
    };
    if (w) $('#wDel', b).onclick = async () => {
      if (workerBalance(w.id).saldo > 0) return toast('Primero paga el saldo pendiente, o márcalo como inactivo', true);
      if (!await confirmBox(`¿Eliminar a ${w.nombre}? Su historial de pagos se conserva.`)) return;
      await Store.remove('trabajadores', w.id); toast('Trabajador eliminado'); go('trabajadores');
    };
  });
};

Forms.trabajo = (t, preset = {}) => {
  const W = Store.list('trabajadores').filter(x => x.activo !== false || x.id === t?.trabajador);
  if (!W.length) { toast('Primero agrega un trabajador'); Forms.trabajador(); return; }
  const w0 = worker(t?.trabajador || preset.trabajador) || W[0];
  const d = t || { fecha: preset.fecha || today(), hora: nowTime(), trabajador: w0.id, lote: preset.lote ?? (state.view === 'lote' ? state.params.id : ''), labor: w0.labor || WORK_LABORS[0], cantidad: 1, unidad: unitOfPay(w0.formaPago), valorUnit: w0.valor, ...preset };
  Sheet.open(t ? 'Editar trabajo' : 'Registrar trabajo', `
    <div class="field"><label>Trabajador</label><select id="jW">${W.map(x => `<option value="${x.id}" ${x.id === d.trabajador ? 'selected' : ''}>${esc(x.nombre)}</option>`).join('')}</select></div>
    <div class="grid2"><div class="field"><label>Fecha</label><input type="date" id="jF" value="${esc(d.fecha)}"></div><div class="field"><label>Hora</label><input type="time" id="jH" value="${esc(d.hora || '')}"></div></div>
    <div class="grid2"><div class="field"><label>Cultivo</label><select id="jL">${loteOptions(d.lote || '')}</select></div><div class="field"><label>Labor</label><select id="jLab">${opts([...new Set([d.labor, ...WORK_LABORS])], d.labor)}</select></div></div>
    <div class="grid3"><div class="field"><label>Cantidad</label><input id="jQ" type="number" inputmode="decimal" value="${esc(d.cantidad)}"></div><div class="field"><label>Unidad</label><select id="jU">${opts([...new Set([d.unidad, ...WORK_UNITS])], d.unidad)}</select></div></div>
    <div class="grid2"><div class="field"><label>Valor por unidad</label><input id="jVU" type="number" inputmode="numeric" value="${esc(d.valorUnit || '')}"></div><div class="field"><label>Total</label><input id="jVT" type="number" inputmode="numeric" value="${esc(d.total || Math.round(num(d.cantidad) * num(d.valorUnit)) || '')}"></div></div>
    <div class="total-box"><span>A pagar por este trabajo</span><b id="jTot">${money(d.total || num(d.cantidad) * num(d.valorUnit))}</b></div>
    ${locFieldHTML('j', d)}
    <div class="field"><label>Notas</label><textarea id="jN" placeholder="Qué hizo, cuántos surcos, observaciones">${esc(d.notas || '')}</textarea></div>
    ${!t ? '<label class="check" style="color:var(--text)"><input type="checkbox" id="jPay"> Se le pagó en el momento</label>' : ''}
    <button class="btn primary block" id="jS">${t ? 'Guardar cambios' : 'Guardar trabajo'}</button>
    ${t ? '<button class="btn danger block" id="jX" style="margin-top:10px">Eliminar registro</button>' : ''}`, b => {
    const getLoc = bindLoc('j', d);
    const upd = (src) => { const q = num($('#jQ').value), vu = num($('#jVU').value), vt = num($('#jVT').value); if (src !== 'vt' && q && vu) $('#jVT').value = Math.round(q * vu); if (src === 'vt' && q && vt) $('#jVU').value = Math.round(vt / q); $('#jTot').textContent = money($('#jVT').value); };
    $('#jW', b).onchange = () => { const w = worker($('#jW').value); if (!w) return; $('#jVU').value = w.valor || ''; const u = unitOfPay(w.formaPago); if (![...$('#jU').options].some(o => o.value === u)) $('#jU').insertAdjacentHTML('afterbegin', `<option>${u}</option>`); $('#jU').value = u; if (w.labor) { if (![...$('#jLab').options].some(o => o.value === w.labor)) $('#jLab').insertAdjacentHTML('afterbegin', `<option>${esc(w.labor)}</option>`); $('#jLab').value = w.labor; } upd('vu'); };
    $('#jQ', b).oninput = () => upd('q'); $('#jVU', b).oninput = () => upd('vu'); $('#jVT', b).oninput = () => upd('vt');
    $('#jS', b).onclick = async () => {
      const data = { trabajador: $('#jW').value, fecha: $('#jF').value || today(), hora: $('#jH').value, lote: $('#jL').value, labor: $('#jLab').value, cantidad: $('#jQ').value, unidad: $('#jU').value, valorUnit: $('#jVU').value, total: num($('#jVT').value) || Math.round(num($('#jQ').value) * num($('#jVU').value)), notas: $('#jN').value.trim(), ...getLoc() };
      if (!data.total) return toast('Escribe el valor del trabajo', true);
      const btn = $('#jS'); btn.disabled = true;
      try {
        const name = workerName(data.trabajador);
        const gData = { fecha: data.fecha, hora: data.hora, lote: data.lote, categoria: 'mano-obra', tipo: data.labor, descripcion: `${data.labor} — ${name}`, cantidad: data.cantidad, unidad: data.unidad, valorUnit: data.valorUnit, total: data.total, proveedor: name, trabajador: data.trabajador, metodo: 'Efectivo', estado: t?.pagado ? 'Pagado' : 'Pendiente', notas: data.notas, lugar: data.lugar, ubicacion: data.ubicacion };
        let tr;
        if (t) {
          tr = await Store.update('trabajos', t.id, data);
          if (t.gastoId && Store.get('gastos', t.gastoId)) await Store.update('gastos', t.gastoId, gData);
        } else {
          tr = await Store.add('trabajos', { ...data, pagado: false });
          const g = await Store.add('gastos', { ...gData, trabajoId: tr.id });
          await Store.update('trabajos', tr.id, { gastoId: g.id });
          if ($('#jPay').checked) {
            const p = await Store.add('pagos', { trabajador: data.trabajador, fecha: data.fecha, hora: data.hora, concepto: 'Pago de jornales', monto: data.total, metodo: 'Efectivo', trabajos: [tr.id], lugar: data.lugar, ubicacion: data.ubicacion });
            await markPaid([tr.id], true, p.id);
          }
        }
        toast(t ? 'Trabajo actualizado' : 'Trabajo registrado ✅'); Sheet.close(); render();
      } catch (e) { btn.disabled = false; toast(authError(e), true); }
    };
    if (t) $('#jX', b).onclick = async () => {
      if (t.pagado && !await confirmBox('Este trabajo ya fue pagado. ¿Eliminarlo de todas formas? El pago se conserva.')) return;
      if (!t.pagado && !await confirmBox('¿Eliminar este registro de trabajo y su gasto?')) return;
      if (t.gastoId) await Store.remove('gastos', t.gastoId);
      await Store.remove('trabajos', t.id); toast('Registro eliminado'); render();
    };
  });
};

async function markPaid(ids, paid, pagoId) {
  for (const id of ids) {
    const t = Store.get('trabajos', id); if (!t) continue;
    await Store.update('trabajos', id, { pagado: paid, pagoId: paid ? pagoId : null });
    if (t.gastoId && Store.get('gastos', t.gastoId)) await Store.update('gastos', t.gastoId, { estado: paid ? 'Pagado' : 'Pendiente' });
  }
}

Forms.pago = (p, preset = {}) => {
  const W = Store.list('trabajadores');
  if (!W.length) { toast('Primero agrega un trabajador'); Forms.trabajador(); return; }
  const wid = preset.trabajador || (W.find(w => workerBalance(w.id).saldo > 0) || W[0]).id;
  const d = { fecha: today(), hora: nowTime(), trabajador: wid, concepto: 'Pago de jornales', metodo: 'Efectivo', ...preset };
  Sheet.open('Pagar a trabajador', `
    <div class="field"><label>Trabajador</label><select id="pW">${W.map(x => `<option value="${x.id}" ${x.id === d.trabajador ? 'selected' : ''}>${esc(x.nombre)}</option>`).join('')}</select></div>
    <div class="field"><label>Concepto</label><div class="chips" style="flex-wrap:wrap">${PAY_CONCEPTS.map(c => `<button class="chip ${c === d.concepto ? 'on' : ''}" data-cc="${c}">${c}</button>`).join('')}</div></div>
    <div id="pPend"></div>
    <div class="grid2"><div class="field"><label>Fecha</label><input type="date" id="pF" value="${esc(d.fecha)}"></div><div class="field"><label>Hora</label><input type="time" id="pH" value="${esc(d.hora)}"></div></div>
    <div class="grid2"><div class="field"><label>Monto pagado</label><input id="pM" type="number" inputmode="numeric" placeholder="$"></div><div class="field"><label>Forma de pago</label><select id="pMet">${opts(PAY_METHODS, d.metodo)}</select></div></div>
    <div class="total-box"><span>Total del pago</span><b id="pTot">$ 0</b></div>
    ${locFieldHTML('p', d)}
    <div class="field"><label>Notas</label><textarea id="pN" placeholder="Recibido por, observaciones"></textarea></div>
    <button class="btn soil block" id="pS">Registrar pago</button>`, b => {
    let concepto = d.concepto;
    const getLoc = bindLoc('p', d);
    const drawPend = () => {
      const wid = $('#pW').value; const bal = workerBalance(wid);
      const box = $('#pPend');
      if (concepto === 'Adelanto' || concepto === 'Bonificación') {
        box.innerHTML = `<div class="banner info">${concepto === 'Adelanto' ? '💡 El adelanto queda como saldo a favor y se descuenta de los próximos trabajos.' : '🎁 La bonificación se suma como gasto de mano de obra.'}</div>`;
        $('#pM').value = ''; $('#pTot').textContent = money(0); return;
      }
      box.innerHTML = bal.pendientes.length ? `<div class="field"><label>Trabajos que cubre este pago</label><div class="pend-list">${bal.pendientes.sort((a, c) => a.fecha.localeCompare(c.fecha)).map(t => `<label class="pend"><input type="checkbox" value="${t.id}" checked><span><b>${fmtDate(t.fecha)}</b> · ${esc(t.labor)} · ${qty(t.cantidad)} ${esc(t.unidad)}</span><b>${money(t.total)}</b></label>`).join('')}</div>
        ${bal.saldo < bal.devengado - bal.pagado + 1 && sum(bal.pendientes, t => t.total) > bal.saldo && bal.saldo > 0 ? `<div class="hint">Tiene ${money(sum(bal.pendientes, t => t.total) - bal.saldo)} en adelantos que se descuentan.</div>` : ''}</div>`
        : `<div class="banner info">✅ ${esc(workerName(wid))} no tiene trabajos pendientes.${bal.saldo < 0 ? ` Tiene ${money(-bal.saldo)} a favor.` : ''}</div>`;
      const recalc = () => { const sel = $$('#pPend input:checked').map(i => Store.get('trabajos', i.value)); let tot = sum(sel, t => t.total); const favor = Math.max(0, -(bal.saldo - sum(bal.pendientes, t => t.total))); tot = Math.max(0, tot - Math.min(favor, tot)); $('#pM').value = tot || ''; $('#pTot').textContent = money(tot); };
      $$('#pPend input').forEach(i => i.onchange = recalc); recalc();
    };
    $('#pW', b).onchange = drawPend;
    $$('[data-cc]', b).forEach(x => x.onclick = () => { concepto = x.dataset.cc; $$('[data-cc]', b).forEach(y => y.classList.toggle('on', y === x)); drawPend(); });
    $('#pM', b).oninput = () => $('#pTot').textContent = money($('#pM').value);
    drawPend();
    $('#pS', b).onclick = async () => {
      const monto = num($('#pM').value); if (!monto) return toast('Escribe el monto pagado', true);
      const ids = (concepto === 'Adelanto' || concepto === 'Bonificación') ? [] : $$('#pPend input:checked').map(i => i.value);
      const data = { trabajador: $('#pW').value, concepto, trabajos: ids, fecha: $('#pF').value || today(), hora: $('#pH').value, monto, metodo: $('#pMet').value, notas: $('#pN').value.trim(), ...getLoc() };
      const btn = $('#pS'); btn.disabled = true;
      try {
        const pg = await Store.add('pagos', data);
        if (ids.length) await markPaid(ids, true, pg.id);
        if (concepto === 'Bonificación') { const g = await Store.add('gastos', { fecha: data.fecha, hora: data.hora, lote: '', categoria: 'mano-obra', tipo: 'Bonificación', descripcion: `Bonificación — ${workerName(data.trabajador)}`, total: monto, proveedor: workerName(data.trabajador), trabajador: data.trabajador, metodo: data.metodo, estado: 'Pagado', lugar: data.lugar, ubicacion: data.ubicacion }); await Store.update('pagos', pg.id, { gastoId: g.id }); }
        toast('Pago registrado 💵');
        Forms.comprobante(Store.get('pagos', pg.id), true);
      } catch (e) { btn.disabled = false; toast(authError(e), true); }
    };
  });
};

function receiptText(p) {
  const w = worker(p.trabajador) || {};
  const tr = (p.trabajos || []).map(id => Store.get('trabajos', id)).filter(Boolean);
  return [`COMPROBANTE DE PAGO — TerraTech`, Store.profile.finca ? `Finca: ${Store.profile.finca}` : '', `Fecha: ${fmtDate(p.fecha)}${p.hora ? ' ' + fmtTime(p.hora) : ''}`,
    `Trabajador: ${w.nombre || ''}${w.documento ? ' · C.C. ' + w.documento : ''}`, `Concepto: ${p.concepto}`,
    ...tr.map(t => `  - ${fmtDate(t.fecha)} ${t.labor}: ${qty(t.cantidad)} ${t.unidad} = ${money(t.total)}`),
    `TOTAL PAGADO: ${money(p.monto)} (${p.metodo})`, p.lugar ? `Lugar: ${p.lugar}` : '', p.ubicacion?.lat != null ? `Ubicación: ${mapsLink(p.ubicacion)}` : '',
    `Pagado por: ${Store.user.name}`, '', `Firma trabajador: ____________________`].filter(x => x !== '').join('\n');
}

Forms.comprobante = (p, recien = false) => {
  if (!p) return;
  const w = worker(p.trabajador) || {};
  const tr = (p.trabajos || []).map(id => Store.get('trabajos', id)).filter(Boolean);
  Sheet.open(recien ? 'Pago registrado' : 'Comprobante de pago', `
    <div class="receipt">
      <div class="r-head"><img src="img/logo.png" alt=""><div><b>Comprobante de pago</b><small>${esc(Store.profile.finca || 'TerraTech')}</small></div></div>
      <div class="r-row"><span>Trabajador</span><b>${esc(w.nombre || '')}</b></div>
      ${w.documento ? `<div class="r-row"><span>Cédula</span><b>${esc(w.documento)}</b></div>` : ''}
      <div class="r-row"><span>Fecha y hora</span><b>${fmtDate(p.fecha)}${p.hora ? ' · ' + fmtTime(p.hora) : ''}</b></div>
      <div class="r-row"><span>Concepto</span><b>${esc(p.concepto)}</b></div>
      ${tr.map(t => `<div class="r-row sub"><span>${fmtDate(t.fecha)} · ${esc(t.labor)} · ${qty(t.cantidad)} ${esc(t.unidad)}</span><span>${money(t.total)}</span></div>`).join('')}
      <div class="r-row"><span>Forma de pago</span><b>${esc(p.metodo)}</b></div>
      ${p.lugar || p.ubicacion ? `<div class="r-row"><span>Lugar</span><b>${placeText(p)}</b></div>` : ''}
      <div class="r-total"><span>Total pagado</span><b>${money(p.monto)}</b></div>
      ${p.notas ? `<p style="font-size:13px;color:var(--muted);margin:8px 0 0">${esc(p.notas)}</p>` : ''}
    </div>
    <div class="btn-row" style="margin-top:14px"><button class="btn sm" id="rCopy">📋 Copiar comprobante</button><button class="btn sm" id="rSave">${ICON.download} Guardar</button></div>
    <button class="btn primary block" id="rOk" style="margin-top:10px">Listo</button>
    ${!recien ? '<button class="btn danger block" id="rDel" style="margin-top:10px">Anular pago</button>' : ''}`, b => {
    $('#rCopy', b).onclick = async () => { try { await navigator.clipboard.writeText(receiptText(p)); toast('Comprobante copiado'); } catch { toast('No se pudo copiar', true); } };
    $('#rSave', b).onclick = () => saveFile(`Comprobante_${(w.nombre || 'pago').replace(/\W+/g, '_')}_${p.fecha}.txt`, receiptText(p));
    $('#rOk', b).onclick = () => { Sheet.close(); render(); };
    if ($('#rDel', b)) $('#rDel', b).onclick = async () => {
      if (!await confirmBox('¿Anular este pago? Los trabajos que cubría vuelven a quedar pendientes.', 'Anular pago')) return;
      if (p.trabajos?.length) await markPaid(p.trabajos, false);
      if (p.gastoId) await Store.remove('gastos', p.gastoId);
      await Store.remove('pagos', p.id); toast('Pago anulado'); render();
    };
  });
};

/* ---------------- Informe detallado del día ---------------- */
function dayData(date) {
  const by = (col) => Store.list(col).filter(x => x.fecha === date);
  return { gastos: by('gastos'), ingresos: by('ingresos'), eventos: by('eventos'), trabajos: by('trabajos'), pagos: by('pagos'), facturas: by('facturas') };
}

function dailyReportHTML(date) {
  const D = dayData(date);
  const ventas = D.ingresos.filter(i => i.tipo !== 'Recolección');
  const recol = D.ingresos.filter(i => i.tipo === 'Recolección');
  const tg = sum(D.gastos, g => g.total), ti = sum(ventas, i => i.total), tp = sum(D.pagos, p => p.monto);
  const kg = sum(D.ingresos, i => i.peso);
  const jornales = sum(D.trabajos.filter(t => /jornal|día/.test(t.unidad)), t => t.unidad === 'medio jornal' ? num(t.cantidad) / 2 : t.cantidad);
  const total = D.gastos.length + D.ingresos.length + D.eventos.length + D.trabajos.length + D.pagos.length;
  if (!total) return `<div class="card day-report"><div class="dr-head"><div><small>Informe del día</small><h3 style="margin:0;text-transform:capitalize">${fmtDateLong(date)}</h3></div></div><div class="empty" style="padding:16px"><p>No hay nada registrado este día.</p></div></div>`;

  // línea de tiempo: gastos de mano de obra ligados a trabajos se muestran como trabajo
  const tl = [];
  D.ingresos.forEach(i => tl.push({ h: i.hora, k: 'ingreso', x: i }));
  D.trabajos.forEach(t => tl.push({ h: t.hora, k: 'trabajo', x: t }));
  D.pagos.forEach(p => tl.push({ h: p.hora, k: 'pago', x: p }));
  D.gastos.filter(g => !g.trabajoId && !(g.tipo === 'Bonificación' && g.trabajador)).forEach(g => tl.push({ h: g.hora, k: 'gasto', x: g }));
  D.eventos.forEach(e => tl.push({ h: e.hora, k: 'evento', x: e }));
  tl.sort((a, b) => (a.h || '99').localeCompare(b.h || '99'));
  const line = ({ k, x }) => {
    if (k === 'ingreso') { const rec = x.tipo === 'Recolección'; return [rec ? '🧺' : '🚚', rec ? `Recolección de ${x.producto || 'producto'}` : `${x.viaje ? 'Viaje/carga ' + esc(x.viaje) + ' · ' : ''}Venta de ${esc(x.producto || 'producto')}`, `${x.cantidad ? qty(x.cantidad) + ' ' + esc(x.unidad) : ''}${x.peso ? ` · ${qty(x.peso)} kg` : ''}${x.precioKg ? ` · ${money(x.precioKg)}/kg` : ''}${x.comprador ? ' · ' + esc(x.comprador) : ''}${x.recolector ? ' · recogió ' + esc(workerName(x.recolector)) : ''} · ${esc(loteName(x.lote))}`, rec ? '' : `<span class="pos">+${money(x.total)}</span>`]; }
    if (k === 'trabajo') return ['👨‍🌾', `${esc(workerName(x.trabajador))} · ${esc(x.labor)}`, `${qty(x.cantidad)} ${esc(x.unidad)} × ${money(x.valorUnit)} · ${esc(loteName(x.lote))} · ${x.pagado ? 'pagado' : 'pendiente de pago'}`, `<span class="neg">-${money(x.total)}</span>`];
    if (k === 'pago') return ['💵', `Pago a ${esc(workerName(x.trabajador))}`, `${esc(payDescr(x))} · ${esc(x.metodo)}`, `<span>${money(x.monto)}</span>`];
    if (k === 'gasto') { const c = cat(x.categoria); return [c.icon, esc(x.descripcion || x.tipo), `${esc(x.tipo || c.name)}${x.cantidad ? ` · ${qty(x.cantidad)} ${esc(x.unidad)}` : ''}${x.proveedor ? ' · ' + esc(x.proveedor) : ''} · ${esc(loteName(x.lote))}${x.facturaId ? ' · 🧾 con factura' : ''}`, `<span class="neg">-${money(x.total)}</span>`]; }
    const t = evType(x.tipo); return [t.icon, `${esc(x.titulo || t.name)}`, `Labor ${x.hecho ? 'realizada ✅' : 'pendiente'} · ${esc(loteName(x.lote))}${x.notas ? ' · ' + esc(x.notas) : ''}`, ''];
  };
  // trabajadores del día
  const wk = {};
  D.trabajos.forEach(t => { const r = wk[t.trabajador] = wk[t.trabajador] || { labores: new Set(), cant: [], total: 0, pagado: 0 }; r.labores.add(t.labor); r.cant.push(`${qty(t.cantidad)} ${t.unidad}`); r.total += num(t.total); });
  D.pagos.forEach(p => { const r = wk[p.trabajador] = wk[p.trabajador] || { labores: new Set(), cant: [], total: 0, pagado: 0 }; r.pagado += num(p.monto); });
  // productos
  const prod = {};
  D.ingresos.forEach(i => { const k = (i.producto || 'Producto') + (i.tipo === 'Recolección' ? ' (recolección)' : ''); const r = prod[k] = prod[k] || { cargas: 0, peso: 0, total: 0, und: {} }; r.cargas++; r.peso += num(i.peso); r.total += num(i.total); if (i.cantidad) r.und[i.unidad] = (r.und[i.unidad] || 0) + num(i.cantidad); });

  return `<div class="card day-report">
    <div class="dr-head"><div><small>Informe del día</small><h3 style="margin:0;text-transform:capitalize">${fmtDateLong(date)}</h3>${Store.profile.finca ? `<small>${esc(Store.profile.finca)}</small>` : ''}</div><button class="btn sm" id="drShare">📤 Compartir</button></div>
    <div class="dr-kpis">
      <div><small>Ventas</small><b class="pos">${money(ti)}</b></div>
      <div><small>Gastos</small><b class="neg">${money(tg)}</b></div>
      <div><small>Balance</small><b class="${ti - tg < 0 ? 'neg' : 'pos'}">${money(ti - tg)}</b></div>
      <div><small>Pagado a trabajadores</small><b>${money(tp)}</b></div>
      <div><small>Peso cosechado/cargado</small><b>${kg ? qty(kg) + ' kg' : '—'}</b></div>
      <div><small>Jornales</small><b>${jornales ? qty(jornales) : '—'}</b></div>
    </div>
    <div class="dr-sec">🕘 Registro detallado</div>
    <div class="timeline">${tl.map(r => { const [ic, t, s, a] = line(r); const where = placeText(r.x); return `<div class="tl" data-tl="${r.k}:${r.x.id}"><div class="tl-time">${r.h ? fmtTime(r.h) : '—'}</div><div class="tl-dot">${ic}</div><div class="tl-body"><b>${t}</b><small>${s}</small>${where ? `<small>${where}</small>` : ''}</div><div class="tl-amt">${a}</div></div>`; }).join('')}</div>
    ${Object.keys(wk).length ? `<div class="dr-sec">👨‍🌾 Trabajadores</div><div style="overflow-x:auto"><table class="tbl"><thead><tr><th>Trabajador</th><th>Labor</th><th class="r">Trabajó</th><th class="r">Pagado</th></tr></thead><tbody>${Object.entries(wk).map(([id, r]) => `<tr><td>${esc(workerName(id))}<br><small style="color:var(--muted)">${r.cant.join(', ')}</small></td><td>${[...r.labores].map(esc).join(', ') || '—'}</td><td class="r">${money(r.total)}</td><td class="r">${money(r.pagado)}</td></tr>`).join('')}</tbody></table></div>` : ''}
    ${Object.keys(prod).length ? `<div class="dr-sec">🚚 Cosecha y ventas</div><div style="overflow-x:auto"><table class="tbl"><thead><tr><th>Producto</th><th class="r">Cantidad</th><th class="r">Peso</th><th class="r">Valor</th></tr></thead><tbody>${Object.entries(prod).map(([k, r]) => `<tr><td>${esc(k)}<br><small style="color:var(--muted)">${r.cargas} registro${r.cargas > 1 ? 's' : ''}${r.peso && r.total ? ' · ' + money(r.total / r.peso) + '/kg' : ''}</small></td><td class="r">${Object.entries(r.und).map(([u, v]) => qty(v) + ' ' + esc(u)).join('<br>') || '—'}</td><td class="r">${r.peso ? qty(r.peso) + ' kg' : '—'}</td><td class="r">${r.total ? money(r.total) : '—'}</td></tr>`).join('')}</tbody></table></div>` : ''}
    ${D.gastos.filter(g => g.cantidad).length ? `<div class="dr-sec">⚖️ Insumos y cantidades usadas</div>${quantityTable(D.gastos)}` : ''}
    ${D.facturas.length ? `<div class="dr-sec">🧾 Facturas del día</div><div class="list">${D.facturas.map(f => `<div class="item" data-fact="${f.id}"><div class="ic">${f.adjunto?.tipo === 'imagen' && f.adjunto.data ? `<img src="${f.adjunto.data}">` : '🧾'}</div><div class="mid"><b>${esc(f.proveedor || 'Factura')}</b><small>${f.numero ? '#' + esc(f.numero) : ''}</small></div><div class="amt">${money(f.total)}</div></div>`).join('')}</div>` : ''}
  </div>`;
}

function dailyReportText(date) {
  const D = dayData(date);
  const L = [`INFORME DEL DÍA — ${fmtDateLong(date)}`, Store.profile.finca ? `Finca: ${Store.profile.finca}` : '', ''];
  const ventas = D.ingresos.filter(i => i.tipo !== 'Recolección');
  L.push(`Ventas: ${money(sum(ventas, i => i.total))}`, `Gastos: ${money(sum(D.gastos, g => g.total))}`, `Pagos a trabajadores: ${money(sum(D.pagos, p => p.monto))}`, `Peso cosechado/cargado: ${qty(sum(D.ingresos, i => i.peso))} kg`, '');
  const rows = [];
  D.ingresos.forEach(i => rows.push([i.hora, `${i.tipo === 'Recolección' ? 'Recolección' : 'Venta'} ${i.producto || ''}: ${i.cantidad ? qty(i.cantidad) + ' ' + i.unidad : ''}${i.peso ? ', ' + qty(i.peso) + ' kg' : ''}${i.total ? ' = ' + money(i.total) : ''}${i.comprador ? ' (' + i.comprador + ')' : ''}${i.lugar ? ' — ' + i.lugar : ''}`]));
  D.trabajos.forEach(t => rows.push([t.hora, `${workerName(t.trabajador)} — ${t.labor}: ${qty(t.cantidad)} ${t.unidad} = ${money(t.total)}${t.lugar ? ' — ' + t.lugar : ''}`]));
  D.pagos.forEach(p => rows.push([p.hora, `Pago a ${workerName(p.trabajador)} (${p.concepto}): ${money(p.monto)}${p.lugar ? ' — ' + p.lugar : ''}`]));
  D.gastos.filter(g => !g.trabajoId).forEach(g => rows.push([g.hora, `Gasto ${g.descripcion || g.tipo}: ${g.cantidad ? qty(g.cantidad) + ' ' + g.unidad + ', ' : ''}${money(g.total)}`]));
  D.eventos.forEach(e => rows.push([e.hora, `Labor ${e.titulo} ${e.hecho ? '(hecha)' : '(pendiente)'}`]));
  rows.sort((a, b) => (a[0] || '99').localeCompare(b[0] || '99')).forEach(([h, t]) => L.push(`${h ? fmtTime(h) : '--'}  ${t}`));
  L.push('', `Generado con TerraTech · ${copyrightLine()}`);
  return L.filter((x, i) => x !== '' || i > 2).join('\n');
}

function bindDailyReport(root, date) {
  const s = $('#drShare', root);
  if (s) s.onclick = async () => {
    const text = dailyReportText(date);
    const cap = window.Capacitor;
    if (cap?.isNativePlatform?.() && cap.Plugins?.Share) { try { await cap.Plugins.Share.share({ title: 'Informe del día', text }); return; } catch {} }
    try { await navigator.clipboard.writeText(text); toast('Informe copiado: pégalo en WhatsApp o donde quieras'); } catch { saveFile(`Informe_${date}.txt`, text); }
  };
  $$('[data-tl]', root).forEach(x => x.onclick = (ev) => {
    if (ev.target.closest('a')) return;
    const [k, id] = x.dataset.tl.split(':');
    ({ ingreso: () => Forms.ingreso(Store.get('ingresos', id)), trabajo: () => Forms.trabajo(Store.get('trabajos', id)), pago: () => Forms.comprobante(Store.get('pagos', id)), gasto: () => Forms.gasto(Store.get('gastos', id)), evento: () => Forms.evento(Store.get('eventos', id)) }[k])();
  });
  $$('[data-fact]', root).forEach(x => x.onclick = () => Forms.factura(Store.get('facturas', x.dataset.fact)));
}
