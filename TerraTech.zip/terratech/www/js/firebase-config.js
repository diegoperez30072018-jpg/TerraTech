/* ============================================================
   TerraTech — Configuración del servidor (Firebase)
   ------------------------------------------------------------
   1. Entra a https://console.firebase.google.com y crea el
      proyecto "terratech" (o usa uno que ya tengas).
   2. Agrega una app Web (icono </>) y copia aquí los valores.
   3. En Authentication > Método de acceso activa "Correo/contraseña".
   4. Crea la base Firestore y pega las reglas de firestore.rules.
   Mientras esto tenga "PEGA_AQUI", la app funciona en MODO LOCAL
   (los datos se guardan solo en el teléfono).
   ============================================================ */
window.TERRATECH_FIREBASE = {
  apiKey: "PEGA_AQUI",
  authDomain: "PEGA_AQUI.firebaseapp.com",
  projectId: "PEGA_AQUI",
  storageBucket: "PEGA_AQUI.appspot.com",
  messagingSenderId: "PEGA_AQUI",
  appId: "PEGA_AQUI"
};
