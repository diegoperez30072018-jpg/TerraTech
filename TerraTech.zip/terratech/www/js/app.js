/* =================================================================
   TerraTech — Cuentas del campo
   App para llevar las cuentas de cultivos: gastos, insumos, cosechas,
   facturas, calendario de labores, informes y PQR.
   © 2026 Juan Diego Pérez Lopez. Todos los derechos reservados.
   Prohibida su copia, distribución o modificación sin autorización.
   ================================================================= */

const APP = {
  name: 'TerraTech',
  version: '1.0.0',
  author: 'Juan Diego Pérez Lopez',
  year: 2026,
  pqrEmail: 'diegoperez30072018@gmail.com'   // correo que recibe las PQR
};

/* ---------------- Utilidades ---------------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = (v) => { const n = parseFloat(String(v ?? '').replace(',', '.')); return isFinite(n) ? n : 0; };
const money = (v) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(Math.round(num(v)));
const moneyShort = (v) => { const n = num(v), a = Math.abs(n); if (a >= 1e9) return '$' + (n / 1e9).toFixed(1).replace('.', ',') + ' mil M'; if (a >= 1e6) return '$' + (n / 1e6).toFixed(1).replace('.', ',') + ' M'; if (a >= 1e3) return '$' + Math.round(n / 1e3) + ' mil'; return money(n); };
const qty = (v) => new Intl.NumberFormat('es-CO', { maximumFractionDigits: 2 }).format(num(v));
const pad = (n) => String(n).padStart(2, '0');
const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const today = () => isoDate(new Date());
const parseDate = (s) => { const [y, m, d] = String(s || today()).split('-').map(Number); return new Date(y, (m || 1) - 1, d || 1); };
const MONTHS = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const MONTHS_S = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
const DOW = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];
const fmtDate = (s) => { if (!s) return ''; const d = parseDate(s); return `${d.getDate()} ${MONTHS_S[d.getMonth()]} ${d.getFullYear()}`; };
const fmtDateLong = (s) => { const d = parseDate(s); return d.toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'long' }); };
const monthLabel = (d) => `${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
const sameMonth = (s, d) => { const x = parseDate(s); return x.getFullYear() === d.getFullYear() && x.getMonth() === d.getMonth(); };
const daysBetween = (a, b) => Math.round((parseDate(b) - parseDate(a)) / 86400000);
const sum = (arr, f) => arr.reduce((t, x) => t + num(f(x)), 0);

const ICON = {
  chevL: '<svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg>',
  chevR: '<svg viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>',
  search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
  eye: '<svg viewBox="0 0 24 24"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  x: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  download: '<svg viewBox="0 0 24 24"><path d="M12 3v12M7 10l5 5 5-5M5 21h14"/></svg>',
  trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
  edit: '<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg>',
  check: '<svg viewBox="0 0 24 24"><path d="M5 12l5 5L20 7"/></svg>'
};

const cat = (id) => EXPENSE_CATEGORIES.find(c => c.id === id) || EXPENSE_CATEGORIES[EXPENSE_CATEGORIES.length - 1];
const evType = (id) => EVENT_TYPES.find(e => e.id === id) || EVENT_TYPES[EVENT_TYPES.length - 1];
const allCrops = () => [...CROPS.filter(c => c.id !== 'otro'), ...Store.list('cultivosPropios').map(c => ({ ...c, group: c.group || 'otros', propio: true })), CROPS.find(c => c.id === 'otro')];
const crop = (id) => allCrops().find(c => c.id === id) || { id, name: 'Cultivo', icon: '🌱', unit: 'kg' };
const lote = (id) => Store.get('lotes', id);
const loteName = (id) => { const l = lote(id); return l ? l.nombre : 'General (toda la finca)'; };
const loteIcon = (id) => { const l = lote(id); return l ? crop(l.cultivo).icon : '🏡'; };

function toast(msg, err = false) {
  const t = $('#toast'); t.textContent = msg; t.className = err ? 'err show' : 'show';
  clearTimeout(t._h); t._h = setTimeout(() => t.className = err ? 'err' : '', 2600);
}

function authError(e) {
  const c = e?.code || '';
  const m = {
    'auth/invalid-email': 'El correo no es válido.',
    'auth/user-not-found': 'No existe una cuenta con ese correo.',
    'auth/wrong-password': 'La contraseña es incorrecta.',
    'auth/invalid-credential': 'Correo o contraseña incorrectos.',
    'auth/invalid-login-credentials': 'Correo o contraseña incorrectos.',
    'auth/email-already-in-use': 'Ya existe una cuenta con ese correo.',
    'auth/weak-password': 'La contraseña debe tener al menos 6 caracteres.',
    'auth/too-many-requests': 'Demasiados intentos. Espera un momento.',
    'auth/network-request-failed': 'Sin conexión a internet.',
    'auth/requires-recent-login': 'Vuelve a iniciar sesión para hacer este cambio.',
    'local/reset': 'En modo local no se puede recuperar por correo. Conecta el servidor (Firebase) para usar esta opción.',
    'local/quota': 'El teléfono no tiene más espacio para guardar. Reduce el tamaño de las fotos o conecta el servidor.'
  };
  return m[c] || e?.message || 'Ocurrió un error. Intenta de nuevo.';
}

/* ---------------- Sello de derechos de autor ---------------- */
function sealSVG(cls = 'seal') {
  return `<img class="${cls}" src="img/sello.png" alt="Sello de derechos de autor de ${APP.author}">`;
}
const copyrightLine = () => `© ${APP.year} ${APP.author}. Todos los derechos reservados.`;

/* ---------------- Hoja modal ---------------- */
const Sheet = {
  open(title, html, onMount) {
    $('#sheetTitle').textContent = title;
    $('#sheetBody').innerHTML = html;
    $('#sheetWrap').hidden = false;
    $('#sheetBody').scrollTop = 0;
    onMount && onMount($('#sheetBody'));
  },
  close() { $('#sheetWrap').hidden = true; $('#sheetBody').innerHTML = ''; }
};
function confirmBox(msg, okText = 'Eliminar') {
  return new Promise(res => {
    Sheet.open('Confirmar', `<p style="margin:4px 0 18px">${esc(msg)}</p>
      <div class="btn-row"><button class="btn" id="cNo">Cancelar</button><button class="btn danger" id="cYes">${esc(okText)}</button></div>`, b => {
      $('#cNo', b).onclick = () => { Sheet.close(); res(false); };
      $('#cYes', b).onclick = () => { Sheet.close(); res(true); };
    });
  });
}

/* ---------------- Archivos, cámara y OCR ---------------- */
function pickFile(kind) {
  return new Promise(res => {
    const input = kind === 'camera' ? $('#fileCamera') : kind === 'backup' ? $('#fileBackup') : $('#fileAny');
    input.value = '';
    input.onchange = () => res(input.files[0] || null);
    input.click();
  });
}
const readAsDataURL = (file) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });

async function compressImage(file, maxSide = 1400, target = 650000) {
  const url = await readAsDataURL(file);
  const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
  let side = maxSide, q = 0.72, out = url;
  for (let tries = 0; tries < 7; tries++) {
    const scale = Math.min(1, side / Math.max(img.width, img.height));
    const c = document.createElement('canvas'); c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
    const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(img, 0, 0, c.width, c.height);
    out = c.toDataURL('image/jpeg', q);
    if (out.length <= target) break;
    side = Math.round(side * 0.82); q = Math.max(0.45, q - 0.07);
  }
  return out;
}

// Convierte archivo en adjunto {tipo, nombre, data}
async function fileToAttachment(file) {
  if (!file) return null;
  if (file.type.startsWith('image/')) return { tipo: 'imagen', nombre: file.name || 'factura.jpg', data: await compressImage(file) };
  if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
    const data = await readAsDataURL(file);
    if (data.length > 900000) { toast('El PDF es muy pesado: se guardan solo los datos, no el archivo.', true); return { tipo: 'pdf', nombre: file.name, data: null }; }
    return { tipo: 'pdf', nombre: file.name, data };
  }
  toast('Formato no soportado. Usa una foto o un PDF.', true); return null;
}

async function loadTesseract() {
  if (window.Tesseract) return window.Tesseract;
  await new Promise((res, rej) => { const s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js'; s.onload = res; s.onerror = () => rej(new Error('Necesitas internet para leer la factura automáticamente.')); document.head.appendChild(s); });
  return window.Tesseract;
}

function parseMoney(s) {
  s = String(s).replace(/[^\d.,]/g, '');
  if (!s) return 0;
  s = s.replace(/[.,](\d{1,2})$/, '');        // quita centavos
  return parseInt(s.replace(/[.,]/g, ''), 10) || 0;
}

function parseInvoiceText(text) {
  const lines = text.split(/\n/).map(l => l.trim()).filter(Boolean);
  const out = {};
  const moneyRe = /\$?\s?\d{1,3}(?:[.,]\d{3})+(?:[.,]\d{1,2})?|\$\s?\d{3,}/g;
  // total
  let best = 0;
  lines.forEach(l => {
    if (/total|neto|pagar|valor\s+a\s+pagar/i.test(l) && !/sub\s*total|subtotal|iva\s*$/i.test(l)) {
      (l.match(moneyRe) || []).forEach(m => { const v = parseMoney(m); if (v > best) best = v; });
    }
  });
  if (!best) (text.match(moneyRe) || []).forEach(m => { const v = parseMoney(m); if (v > best) best = v; });
  if (best) out.total = best;
  // fecha
  let m = text.match(/(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (m) out.fecha = `${m[1]}-${pad(m[2])}-${pad(m[3])}`;
  else if ((m = text.match(/(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})/))) { let y = m[3].length === 2 ? '20' + m[3] : m[3]; if (+m[2] <= 12) out.fecha = `${y}-${pad(m[2])}-${pad(m[1])}`; }
  // NIT
  m = text.match(/N\.?\s?I\.?\s?T\.?\s*[:.#]?\s*([\d.\s-]{6,16})/i); if (m) out.nit = m[1].replace(/\s/g, '');
  // número
  m = text.match(/(?:factura(?:\s+(?:electr[oó]nica|de\s+venta))?|fact|fv|No\.?|N[°º])\s*[:#.]?\s*([A-Z]{0,5}[-\s]?\d{2,10})/i); if (m) out.numero = m[1].replace(/\s/g, '');
  // proveedor: primera línea con letras, sin palabras genéricas
  const prov = lines.find(l => /[a-záéíóúñ]{3,}/i.test(l) && !/factura|nit|fecha|tel|direcci|r[eé]gimen|resoluci/i.test(l));
  if (prov) out.proveedor = prov.slice(0, 60);
  return out;
}

async function saveFile(name, content, mime = 'text/plain') {
  const cap = window.Capacitor;
  if (cap && cap.isNativePlatform && cap.isNativePlatform() && cap.Plugins?.Filesystem) {
    try {
      const { Filesystem, Share } = cap.Plugins;
      const isData = typeof content === 'string' && content.startsWith('data:');
      const data = isData ? content.split(',')[1] : content;
      const r = await Filesystem.writeFile({ path: name, data, directory: 'CACHE', ...(isData ? {} : { encoding: 'utf8' }) });
      if (Share) await Share.share({ title: name, url: r.uri, dialogTitle: 'Guardar o compartir' });
      else toast('Archivo guardado');
      return;
    } catch (e) { console.warn(e); if (String(e?.message || e).toLowerCase().includes('cancel')) return; }
  }
  const blob = content.startsWith?.('data:') ? await (await fetch(content)).blob() : new Blob([content], { type: mime });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}

const csvCell = (v) => { const s = String(v ?? ''); return /[",;\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
const toCSV = (rows) => '﻿' + rows.map(r => r.map(csvCell).join(';')).join('\n');

/* ---------------- Estado y navegación ---------------- */
const state = { view: 'inicio', params: {}, month: new Date(new Date().getFullYear(), new Date().getMonth(), 1), calSel: today(), filters: {} };
const ROOTS = ['inicio', 'cultivos', 'gastos', 'calendario', 'mas'];
const TITLES = {
  inicio: 'TerraTech', cultivos: 'Mis cultivos', lote: 'Cultivo', gastos: 'Gastos', ingresos: 'Cargas y ventas', facturas: 'Facturas',
  calendario: 'Calendario', trabajadores: 'Trabajadores', trabajador: 'Trabajador', informes: 'Informes', pqr: 'PQR', perfil: 'Mi perfil', autor: 'Derechos de autor', mas: 'Más opciones', catalogo: 'Catálogo de cultivos'
};

function go(view, params = {}, push = true) {
  state.view = view; state.params = params;
  if (push) history.pushState({ view, params }, '');
  render();
  window.scrollTo(0, 0);
}
window.addEventListener('popstate', (e) => {
  if (!$('#sheetWrap').hidden) { Sheet.close(); history.pushState({ view: state.view, params: state.params }, ''); return; }
  const s = e.state || { view: 'inicio', params: {} };
  state.view = s.view; state.params = s.params || {}; render();
});

function render() {
  if (!Store.user) return;
  const v = state.view;
  $('#viewTitle').textContent = v === 'lote' ? (lote(state.params.id)?.nombre || 'Cultivo') : v === 'trabajador' ? (worker(state.params.id)?.nombre || 'Trabajador') : TITLES[v] || 'TerraTech';
  $('#viewSub').textContent = v === 'inicio' ? (Store.profile.finca || 'Cuentas del campo') : v === 'lote' ? crop(lote(state.params.id)?.cultivo).name : '';
  $('#btnBack').hidden = ROOTS.includes(v);
  $('#topLogo').hidden = !ROOTS.includes(v);
  const sb = $('#syncBadge');
  sb.textContent = Store.mode === 'firebase' ? '☁ Sincronizado' : '📱 Local';
  sb.className = 'sync-badge ' + (Store.mode === 'firebase' ? '' : 'local');
  $$('#bottomnav button').forEach(b => b.classList.toggle('active', b.dataset.go === v || (v === 'lote' && b.dataset.go === 'cultivos') || (['ingresos', 'facturas', 'informes', 'pqr', 'perfil', 'autor', 'catalogo', 'trabajadores', 'trabajador'].includes(v) && b.dataset.go === 'mas')));
  const fabViews = ['inicio', 'cultivos', 'lote', 'gastos', 'ingresos', 'facturas', 'calendario', 'pqr', 'catalogo', 'trabajadores', 'trabajador'];
  $('#fab').hidden = !fabViews.includes(v);
  const el = $('#view');
  el.style.animation = 'none'; el.offsetHeight; el.style.animation = '';
  (Views[v] || Views.inicio)(el);
}

/* ---------------- Componentes reutilizables ---------------- */
function periodNav(id) {
  return `<div class="period" id="${id}"><button data-d="-1" aria-label="Mes anterior">${ICON.chevL}</button><span>${monthLabel(state.month)}</span><button data-d="1" aria-label="Mes siguiente">${ICON.chevR}</button></div>`;
}
function bindPeriod(root, id) {
  $$(`#${id} button`, root).forEach(b => b.onclick = () => { state.month = new Date(state.month.getFullYear(), state.month.getMonth() + num(b.dataset.d), 1); render(); });
}
function barsHTML(rows, total) {
  if (!rows.length) return '<div class="empty" style="padding:14px"><p>Sin datos en este periodo</p></div>';
  const max = Math.max(...rows.map(r => r.value), 1);
  return `<div class="bars">${rows.map(r => `<div class="bar-row"><div class="top"><span>${r.icon ? r.icon + ' ' : ''}${esc(r.label)}</span><b>${money(r.value)}${total ? ` <small style="color:var(--muted);font-weight:500">${Math.round(r.value / total * 100)}%</small>` : ''}</b></div><div class="bar-track"><div class="bar-fill" style="width:${(r.value / max * 100).toFixed(1)}%;background:${r.color || 'var(--g600)'}"></div></div></div>`).join('')}</div>`;
}
function gastoItem(g) {
  const c = cat(g.categoria);
  return `<div class="item" data-gasto="${g.id}"><div class="ic" style="background:${c.color}1f">${c.icon}</div>
    <div class="mid"><b>${esc(g.descripcion || g.tipo || c.name)}</b><small>${esc(g.tipo || c.name)} · ${esc(loteName(g.lote))}${g.cantidad ? ` · ${qty(g.cantidad)} ${esc(g.unidad || '')}` : ''}</small></div>
    <div class="amt neg">-${money(g.total)}<small>${fmtDate(g.fecha)}${g.estado === 'Pendiente' ? ' · <span class="tag red">Debe</span>' : ''}${g.facturaId ? ' 🧾' : ''}</small></div></div>`;
}
function ingresoItem(i) {
  const rec = i.tipo === 'Recolección';
  return `<div class="item" data-ingreso="${i.id}"><div class="ic" style="background:#6CC24A22">${rec ? '🧺' : i.viaje || i.peso ? '🚚' : loteIcon(i.lote)}</div>
    <div class="mid"><b>${esc(i.producto || i.tipo)}${i.viaje ? ' · Carga ' + esc(i.viaje) : ''}</b><small>${esc(rec ? 'Recolección' : i.tipo)} · ${esc(loteName(i.lote))}${i.cantidad ? ` · ${qty(i.cantidad)} ${esc(i.unidad || '')}` : ''}${i.peso ? ` · ${qty(i.peso)} kg` : ''}${i.hora ? ' · ' + fmtTime(i.hora) : ''}</small>${i.lugar || i.ubicacion ? `<small>${placeText(i)}</small>` : ''}</div>
    <div class="amt ${rec ? '' : 'pos'}">${rec ? (i.peso ? qty(i.peso) + ' kg' : qty(i.cantidad) + ' ' + esc(i.unidad || '')) : '+' + money(i.total)}<small>${fmtDate(i.fecha)}${i.estado === 'Por cobrar' ? ' · <span class="tag gold">Por cobrar</span>' : ''}</small></div></div>`;
}
function eventoItem(e) {
  const t = evType(e.tipo);
  return `<div class="item" data-evento="${e.id}"><div class="ic" style="background:${t.color}22">${t.icon}</div>
    <div class="mid"><b style="${e.hecho ? 'text-decoration:line-through;opacity:.6' : ''}">${esc(e.titulo || t.name)}</b><small>${fmtDate(e.fecha)}${e.hora ? ' · ' + e.hora : ''} · ${esc(loteName(e.lote))}</small></div>
    <button class="btn sm" data-done="${e.id}" aria-label="Marcar hecho">${e.hecho ? '↺' : ICON.check}</button></div>`;
}
function bindItems(root) {
  $$('[data-gasto]', root).forEach(x => x.onclick = () => Forms.gasto(Store.get('gastos', x.dataset.gasto)));
  $$('[data-ingreso]', root).forEach(x => x.onclick = () => Forms.ingreso(Store.get('ingresos', x.dataset.ingreso)));
  $$('[data-evento]', root).forEach(x => x.onclick = (ev) => { if (ev.target.closest('[data-done]')) return; Forms.evento(Store.get('eventos', x.dataset.evento)); });
  $$('[data-done]', root).forEach(b => b.onclick = async (ev) => { ev.stopPropagation(); const e = Store.get('eventos', b.dataset.done); await Store.update('eventos', e.id, { hecho: !e.hecho }); toast(e.hecho ? 'Labor pendiente' : '¡Labor completada!'); });
  $$('[data-lote]', root).forEach(x => x.onclick = () => go('lote', { id: x.dataset.lote }));
}
function loteOptions(sel, withGeneral = true) {
  const ls = Store.list('lotes').sort((a, b) => a.nombre.localeCompare(b.nombre));
  return (withGeneral ? `<option value="">🏡 General (toda la finca)</option>` : '') + ls.map(l => `<option value="${l.id}" ${l.id === sel ? 'selected' : ''}>${crop(l.cultivo).icon} ${esc(l.nombre)}</option>`).join('');
}
const opts = (arr, sel) => arr.map(o => `<option ${o === sel ? 'selected' : ''}>${esc(o)}</option>`).join('');
const emptyBox = (icon, title, text, btn, action) => `<div class="empty"><div class="big">${icon}</div><b>${title}</b><p>${text}</p>${btn ? `<button class="btn primary" data-empty="${action}">${btn}</button>` : ''}</div>`;
function bindEmpty(root) {
  $$('[data-empty]', root).forEach(b => b.onclick = () => ({ lote: () => Forms.lote(), gasto: () => Forms.gasto(), ingreso: () => Forms.ingreso(), factura: () => Forms.nuevaFactura(), pqr: () => Forms.pqr(), evento: () => Forms.evento() }[b.dataset.empty])());
}

/* ---------------- Pantallas ---------------- */
const Views = {};

Views.inicio = (el) => {
  const m = state.month;
  const gastos = Store.list('gastos').filter(g => sameMonth(g.fecha, m));
  const ingresos = Store.list('ingresos').filter(i => sameMonth(i.fecha, m));
  const tg = sum(gastos, g => g.total), ti = sum(ingresos, i => i.total), bal = ti - tg;
  const byCat = EXPENSE_CATEGORIES.map(c => ({ label: c.name, icon: c.icon, color: c.color, value: sum(gastos.filter(g => g.categoria === c.id), g => g.total) })).filter(r => r.value > 0).sort((a, b) => b.value - a.value);
  const t = today();
  const prox = Store.list('eventos').filter(e => !e.hecho && e.fecha >= t && daysBetween(t, e.fecha) <= 21).sort((a, b) => (a.fecha + (a.hora || '')).localeCompare(b.fecha + (b.hora || ''))).slice(0, 5);
  const atrasadas = Store.list('eventos').filter(e => !e.hecho && e.fecha < t).length;
  const movs = [...Store.list('gastos').map(g => ({ ...g, _k: 'g' })), ...Store.list('ingresos').map(i => ({ ...i, _k: 'i' }))].sort((a, b) => (b.fecha + b.creado).localeCompare(a.fecha + a.creado)).slice(0, 6);
  const lotes = Store.list('lotes').filter(l => l.estado !== 'Finalizado');
  const first = (Store.user.name || '').split(' ')[0];
  const hour = new Date().getHours();
  const saludo = hour < 12 ? 'Buenos días' : hour < 19 ? 'Buenas tardes' : 'Buenas noches';

  el.innerHTML = `
    ${Store.mode === 'local' ? `<div class="banner warn">📱 <div><b>Modo local.</b> Tus datos se guardan solo en este teléfono. Conecta el servidor para sincronizar tu cuenta.</div></div>` : ''}
    <div class="hero">
      <div class="hi">${saludo}, <b>${esc(first)}</b> 👋</div>
      ${periodNav('pHome')}
      <div class="bal-label">Balance del mes</div>
      <div class="bal">${bal < 0 ? '-' : ''}${money(Math.abs(bal))}</div>
      <div class="row">
        <div class="pill"><small>⬆ Ingresos</small><b>${money(ti)}</b></div>
        <div class="pill"><small>⬇ Gastos</small><b>${money(tg)}</b></div>
      </div>
    </div>
    <div class="quick">
      <button data-q="gasto"><span class="qi">🧾</span>Gasto</button>
      <button data-q="venta"><span class="qi">🚚</span>Carga / venta</button>
      <button data-q="recol"><span class="qi">🧺</span>Recolección</button>
      <button data-q="scan"><span class="qi">📷</span>Escanear</button>
      <button data-q="jornal"><span class="qi">📝</span>Jornal</button>
      <button data-q="pagar"><span class="qi">💵</span>Pagar</button>
      <button data-q="trab"><span class="qi">👨‍🌾</span>Trabajadores</button>
      <button data-q="evento"><span class="qi">📅</span>Labor</button>
      <button data-q="lote"><span class="qi">🌱</span>Cultivo</button>
      <button data-q="hoy"><span class="qi">📋</span>Informe hoy</button>
      <button data-q="informes"><span class="qi">📊</span>Informes</button>
      <button data-q="facturas"><span class="qi">🗂️</span>Facturas</button>
    </div>
    ${(() => { const deuda = sum(Store.list('trabajadores'), w => Math.max(0, workerBalance(w.id).saldo)); return deuda ? `<div class="banner warn" style="cursor:pointer" data-nav="trabajadores">👨‍🌾 <div>Debes <b>${money(deuda)}</b> a trabajadores. Toca para pagar.</div></div>` : ''; })()}
    <div class="card"><h3>💸 Gastos por tipo <span class="right">${monthLabel(m)}</span></h3>${barsHTML(byCat, tg)}</div>
    <div class="card"><h3>📅 Próximas labores ${atrasadas ? `<span class="tag red" style="margin:0 0 0 auto">${atrasadas} atrasada${atrasadas > 1 ? 's' : ''}</span>` : ''}</h3>
      ${prox.length ? `<div class="list">${prox.map(eventoItem).join('')}</div>` : `<div class="empty" style="padding:10px"><p>No tienes labores programadas en las próximas 3 semanas.</p><button class="btn sm" data-empty="evento">Programar labor</button></div>`}
    </div>
    <div class="card"><h3>🌱 Mis cultivos <span class="right" data-nav="cultivos" style="cursor:pointer">Ver todos ›</span></h3>
      ${lotes.length ? `<div class="list">${lotes.slice(0, 4).map(l => { const g = sum(Store.list('gastos').filter(x => x.lote === l.id), x => x.total), i = sum(Store.list('ingresos').filter(x => x.lote === l.id), x => x.total); return `<div class="item" data-lote="${l.id}"><div class="ic">${crop(l.cultivo).icon}</div><div class="mid"><b>${esc(l.nombre)}</b><small>${esc(crop(l.cultivo).name)} · ${esc(l.estado || '')}</small></div><div class="amt ${i - g < 0 ? 'neg' : 'pos'}">${money(i - g)}<small>balance</small></div></div>`; }).join('')}</div>`
        : `<div class="empty" style="padding:10px"><p>Registra tu primer cultivo: plátano, maíz, maracuyá, café…</p><button class="btn primary sm" data-empty="lote">Agregar cultivo</button></div>`}
    </div>
    <div class="card"><h3>🕘 Últimos movimientos</h3>
      ${movs.length ? `<div class="list">${movs.map(x => x._k === 'g' ? gastoItem(x) : ingresoItem(x)).join('')}</div>` : '<div class="empty" style="padding:10px"><p>Aún no hay movimientos.</p></div>'}
    </div>
    <div class="foot-copy">${copyrightLine()}</div>`;
  bindPeriod(el, 'pHome');
  $$('[data-q]', el).forEach(b => b.onclick = () => ({
    gasto: () => Forms.gasto(), venta: () => Forms.ingreso(), recol: () => Forms.ingreso(null, { tipo: 'Recolección' }), scan: () => Forms.nuevaFactura('camera'), evento: () => Forms.evento(),
    jornal: () => Forms.trabajo(), pagar: () => Forms.pago(), trab: () => go('trabajadores'), hoy: () => { state.filters.rPer = 'dia'; state.filters.rDay = today(); go('informes'); },
    lote: () => Forms.lote(), informes: () => go('informes'), facturas: () => go('facturas'), pqr: () => go('pqr')
  }[b.dataset.q])());
  $$('[data-nav]', el).forEach(b => b.onclick = () => go(b.dataset.nav));
  bindItems(el); bindEmpty(el);
};

Views.cultivos = (el) => {
  const q = (state.filters.lotQ || '').toLowerCase();
  const lotes = Store.list('lotes').filter(l => !q || (l.nombre + crop(l.cultivo).name).toLowerCase().includes(q)).sort((a, b) => (a.estado === 'Finalizado') - (b.estado === 'Finalizado') || a.nombre.localeCompare(b.nombre));
  const G = Store.list('gastos'), I = Store.list('ingresos');
  const totalArea = sum(Store.list('lotes').filter(l => l.estado !== 'Finalizado' && (l.unidadArea || 'ha') === 'ha'), l => l.area);
  el.innerHTML = `
    <div class="search">${ICON.search}<input id="lotQ" placeholder="Buscar cultivo o lote" value="${esc(state.filters.lotQ || '')}"></div>
    ${Store.list('lotes').length ? `<div class="banner info">🌾 <div><b>${Store.list('lotes').filter(l => l.estado !== 'Finalizado').length}</b> cultivos activos${totalArea ? ` · <b>${qty(totalArea)} ha</b> sembradas` : ''}</div></div>` : ''}
    ${lotes.length ? lotes.map(l => {
      const c = crop(l.cultivo); const g = sum(G.filter(x => x.lote === l.id), x => x.total), i = sum(I.filter(x => x.lote === l.id), x => x.total);
      return `<div class="card"><div class="lot-card" data-lote="${l.id}"><div class="lot-ic">${c.icon}</div><div class="mid"><b>${esc(l.nombre)}</b><small>${esc(c.name)}${l.area ? ` · ${qty(l.area)} ${esc(l.unidadArea || 'ha')}` : ''}${l.plantas ? ` · ${qty(l.plantas)} plantas` : ''}</small>
        <span class="tag ${l.estado === 'Finalizado' ? 'soil' : ''}">${esc(l.estado || 'Sembrado')}</span>${l.siembra ? ` <span class="tag gold">${daysBetween(l.siembra, today())} días</span>` : ''}</div>${ICON.chevR}</div>
        <div class="lot-stats"><div><small>Invertido</small><b class="neg">${moneyShort(g)}</b></div><div><small>Ingresos</small><b class="pos">${moneyShort(i)}</b></div><div><small>Balance</small><b class="${i - g < 0 ? 'neg' : 'pos'}">${moneyShort(i - g)}</b></div></div></div>`;
    }).join('') : emptyBox('🌱', q ? 'Sin resultados' : 'Aún no tienes cultivos', q ? 'Prueba con otro nombre.' : `Agrega tus lotes de plátano, maíz, maracuyá o cualquiera de los ${CROPS.length - 1} cultivos del catálogo.`, q ? '' : 'Agregar cultivo', 'lote')}
    <button class="btn block" id="toCat" style="margin-top:6px">📚 Ver catálogo de cultivos</button>`;
  const inp = $('#lotQ', el); inp.oninput = () => { state.filters.lotQ = inp.value; const pos = inp.selectionStart; render(); const n = $('#lotQ'); n.focus(); n.setSelectionRange(pos, pos); };
  $('#toCat', el).onclick = () => go('catalogo');
  bindItems(el); bindEmpty(el);
};

Views.lote = (el) => {
  const l = lote(state.params.id);
  if (!l) { el.innerHTML = emptyBox('🤷', 'Cultivo no encontrado', 'Pudo haber sido eliminado.', '', ''); return; }
  const c = crop(l.cultivo);
  const G = Store.list('gastos').filter(g => g.lote === l.id).sort((a, b) => b.fecha.localeCompare(a.fecha));
  const I = Store.list('ingresos').filter(i => i.lote === l.id).sort((a, b) => b.fecha.localeCompare(a.fecha));
  const E = Store.list('eventos').filter(e => e.lote === l.id).sort((a, b) => b.fecha.localeCompare(a.fecha));
  const tg = sum(G, g => g.total), ti = sum(I, i => i.total);
  const tab = state.filters.lotTab || 'gastos';
  const cosechado = {}; I.forEach(i => { if (i.cantidad) { const k = i.unidad || 'und'; cosechado[k] = (cosechado[k] || 0) + num(i.cantidad); } if (num(i.peso)) cosechado.kg = (cosechado.kg || 0) + num(i.peso); });
  const areaHa = (l.unidadArea || 'ha') === 'ha' ? num(l.area) : (l.unidadArea === 'm²' ? num(l.area) / 10000 : l.unidadArea === 'fanegada' ? num(l.area) * 0.64 : l.unidadArea === 'cuadra' ? num(l.area) * 0.64 : 0);
  el.innerHTML = `
    <div class="hero">
      <div class="hi" style="display:flex;align-items:center;gap:10px"><span style="font-size:34px">${c.icon}</span><div><b style="font-size:17px">${esc(l.nombre)}</b><br><small>${esc(c.name)} · ${esc(l.estado || '')}${l.vereda ? ' · ' + esc(l.vereda) : ''}</small></div></div>
      <div class="bal-label">Balance del cultivo</div>
      <div class="bal">${ti - tg < 0 ? '-' : ''}${money(Math.abs(ti - tg))}</div>
      <div class="row"><div class="pill"><small>Invertido</small><b>${money(tg)}</b></div><div class="pill"><small>Ingresos</small><b>${money(ti)}</b></div></div>
    </div>
    <div class="card"><div class="lot-stats" style="margin:0;padding:0;border:0;grid-template-columns:repeat(2,1fr);row-gap:12px">
      <div><small>Área</small><b>${l.area ? qty(l.area) + ' ' + esc(l.unidadArea || 'ha') : '—'}</b></div>
      <div><small>Plantas</small><b>${l.plantas ? qty(l.plantas) : '—'}</b></div>
      <div><small>Siembra</small><b>${l.siembra ? fmtDate(l.siembra) : '—'}</b></div>
      <div><small>Cosecha estimada</small><b>${l.cosechaEst ? fmtDate(l.cosechaEst) : '—'}</b></div>
      <div><small>Costo por hectárea</small><b>${areaHa ? money(tg / areaHa) : '—'}</b></div>
      <div><small>Costo por planta</small><b>${num(l.plantas) ? money(tg / num(l.plantas)) : '—'}</b></div>
      <div style="grid-column:span 2"><small>Total cosechado</small><b>${Object.keys(cosechado).length ? Object.entries(cosechado).map(([u, v]) => `${qty(v)} ${esc(u)}`).join(' · ') : '—'}</b></div>
    </div>${l.notas ? `<p style="color:var(--muted);font-size:13.5px;margin:12px 0 0">📝 ${esc(l.notas)}</p>` : ''}</div>
    <div class="btn-row" style="margin-bottom:14px">
      <button class="btn sm" id="lg">🧾 Gasto</button><button class="btn sm" id="li">🧺 Cosecha</button><button class="btn sm" id="lj">👨‍🌾 Jornal</button><button class="btn sm" id="le">📅 Labor</button><button class="btn sm" id="led">${ICON.edit}</button>
    </div>
    <div class="chips">${[['gastos', `Gastos (${G.length})`], ['ingresos', `Cosechas y ventas (${I.length})`], ['labores', `Labores (${E.length})`], ['insumos', 'Cantidades usadas']].map(([k, n]) => `<button class="chip ${tab === k ? 'on' : ''}" data-tab="${k}">${n}</button>`).join('')}</div>
    <div class="card">${tab === 'gastos' ? (G.length ? `<div class="list">${G.map(gastoItem).join('')}</div>` : emptyBox('🧾', 'Sin gastos', 'Registra insumos, jornales y demás gastos de este cultivo.', 'Agregar gasto', 'gasto'))
      : tab === 'ingresos' ? (I.length ? `<div class="list">${I.map(ingresoItem).join('')}</div>` : emptyBox('🧺', 'Sin cosechas', 'Registra lo que cosechas y vendes.', 'Registrar cosecha', 'ingreso'))
      : tab === 'labores' ? (E.length ? `<div class="list">${E.map(eventoItem).join('')}</div>` : emptyBox('📅', 'Sin labores', 'Programa siembras, abonadas, fumigaciones y cosechas.', 'Programar labor', 'evento'))
      : quantityTable(G)}</div>`;
  $('#lg', el).onclick = () => Forms.gasto(null, { lote: l.id });
  $('#li', el).onclick = () => Forms.ingreso(null, { lote: l.id });
  $('#le', el).onclick = () => Forms.evento(null, { lote: l.id });
  $('#lj', el).onclick = () => Forms.trabajo(null, { lote: l.id });
  $('#led', el).onclick = () => Forms.lote(l);
  $$('[data-tab]', el).forEach(b => b.onclick = () => { state.filters.lotTab = b.dataset.tab; render(); });
  bindItems(el);
  $$('[data-empty]', el).forEach(b => b.onclick = () => ({ gasto: () => Forms.gasto(null, { lote: l.id }), ingreso: () => Forms.ingreso(null, { lote: l.id }), evento: () => Forms.evento(null, { lote: l.id }) }[b.dataset.empty])());
};

// Tabla de cantidades utilizadas, agrupada por tipo
function quantityTable(G) {
  if (!G.length) return '<div class="empty" style="padding:14px"><p>Sin datos</p></div>';
  const groups = {};
  G.forEach(g => {
    const c = g.categoria || 'otros'; const k = `${g.tipo || '—'}|${(g.descripcion || '').trim().toLowerCase()}|${g.unidad || ''}`;
    groups[c] = groups[c] || { total: 0, rows: {} };
    groups[c].total += num(g.total);
    const r = groups[c].rows[k] = groups[c].rows[k] || { tipo: g.tipo || '—', prod: g.descripcion || '', unidad: g.unidad || '', cant: 0, valor: 0 };
    r.cant += num(g.cantidad); r.valor += num(g.total);
  });
  const order = EXPENSE_CATEGORIES.map(c => c.id).filter(id => groups[id]);
  return `<div style="overflow-x:auto"><table class="tbl"><thead><tr><th>Tipo / producto</th><th class="r">Cantidad</th><th class="r">Valor</th></tr></thead><tbody>
    ${order.map(id => { const c = cat(id); const g = groups[id]; return `<tr class="grp"><td>${c.icon} ${esc(c.name)}</td><td></td><td class="r">${money(g.total)}</td></tr>` +
      Object.values(g.rows).sort((a, b) => b.valor - a.valor).map(r => `<tr><td>${esc(r.tipo)}${r.prod ? `<br><small style="color:var(--muted)">${esc(r.prod)}</small>` : ''}</td><td class="r">${r.cant ? qty(r.cant) + ' ' + esc(r.unidad) : '—'}</td><td class="r">${money(r.valor)}</td></tr>`).join(''); }).join('')}
  </tbody></table></div>`;
}

Views.gastos = (el) => {
  const f = state.filters; const m = state.month;
  let G = Store.list('gastos').filter(g => f.allTime || sameMonth(g.fecha, m));
  if (f.gCat) G = G.filter(g => g.categoria === f.gCat);
  if (f.gLote !== undefined && f.gLote !== null && f.gLote !== 'todos') G = G.filter(g => (g.lote || '') === f.gLote);
  G.sort((a, b) => (b.fecha + b.creado).localeCompare(a.fecha + a.creado));
  const tot = sum(G, g => g.total), pend = sum(G.filter(g => g.estado === 'Pendiente'), g => g.total);
  const byDate = {}; G.forEach(g => (byDate[g.fecha] = byDate[g.fecha] || []).push(g));
  el.innerHTML = `
    <div class="card" style="padding:14px">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
        <div><small style="color:var(--muted)">Total gastado</small><div style="font-size:26px;font-weight:800" class="neg">${money(tot)}</div>${pend ? `<small class="neg">Pendiente por pagar: ${money(pend)}</small>` : ''}</div>
        <div style="text-align:right">${f.allTime ? '<b>Todo el tiempo</b>' : `<div class="period" id="pG" style="color:var(--text)">${periodNav('pG').replace(/^<div class="period" id="pG">/, '').replace(/<\/div>$/, '')}</div>`}<button class="link-btn" id="allT">${f.allTime ? 'Ver por mes' : 'Ver todo'}</button></div>
      </div>
    </div>
    <div class="chips"><button class="chip ${!f.gCat ? 'on' : ''}" data-c="">Todos</button>${EXPENSE_CATEGORIES.map(c => `<button class="chip ${f.gCat === c.id ? 'on' : ''}" data-c="${c.id}">${c.icon} ${c.name}</button>`).join('')}</div>
    <div class="field"><select id="gLote"><option value="todos">🌾 Todos los cultivos</option>${loteOptions(f.gLote, true)}</select></div>
    ${G.length ? Object.keys(byDate).map(d => `<div class="section-title">${fmtDateLong(d)}</div><div class="card" style="padding:4px 14px"><div class="list">${byDate[d].map(gastoItem).join('')}</div></div>`).join('')
      : emptyBox('🧾', 'Sin gastos', f.allTime ? 'Aún no registras gastos.' : `No hay gastos en ${monthLabel(m)} con estos filtros.`, 'Registrar gasto', 'gasto')}`;
  $$('#pG button', el).forEach(b => { b.style.background = 'var(--surface-2)'; b.style.color = 'var(--text)'; b.onclick = () => { state.month = new Date(m.getFullYear(), m.getMonth() + num(b.dataset.d), 1); render(); }; });
  const allT = $('#allT', el); allT.onclick = () => { f.allTime = !f.allTime; render(); };
  $$('[data-c]', el).forEach(b => b.onclick = () => { f.gCat = b.dataset.c; render(); });
  const sel = $('#gLote', el); if (f.gLote === undefined || f.gLote === 'todos') sel.value = 'todos'; sel.onchange = () => { f.gLote = sel.value; render(); };
  bindItems(el); bindEmpty(el);
};

Views.ingresos = (el) => {
  const f = state.filters; const m = state.month;
  let I = Store.list('ingresos').filter(i => f.iAll || sameMonth(i.fecha, m));
  I.sort((a, b) => (b.fecha + b.creado).localeCompare(a.fecha + a.creado));
  const tot = sum(I, i => i.total), porCobrar = sum(I.filter(i => i.estado === 'Por cobrar'), i => i.total);
  el.innerHTML = `
    <div class="card" style="padding:14px"><div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
      <div><small style="color:var(--muted)">Total ingresos</small><div style="font-size:26px;font-weight:800" class="pos">${money(tot)}</div>${porCobrar ? `<small style="color:#8A6A0E">Por cobrar: ${money(porCobrar)}</small>` : ''}</div>
      <div style="text-align:right">${f.iAll ? '<b>Todo el tiempo</b>' : `<div class="period" id="pI">${periodNav('pI').replace(/^<div class="period" id="pI">/, '').replace(/<\/div>$/, '')}</div>`}<button class="link-btn" id="allI">${f.iAll ? 'Ver por mes' : 'Ver todo'}</button></div>
    </div></div>
    ${I.length ? `<div class="card" style="padding:4px 14px"><div class="list">${I.map(ingresoItem).join('')}</div></div>` : emptyBox('🧺', 'Sin cosechas ni ventas', 'Registra lo que vendes: racimos de plátano, bultos de maíz, kilos de maracuyá…', 'Registrar cosecha', 'ingreso')}`;
  $$('#pI button', el).forEach(b => { b.style.background = 'var(--surface-2)'; b.style.color = 'var(--text)'; b.onclick = () => { state.month = new Date(m.getFullYear(), m.getMonth() + num(b.dataset.d), 1); render(); }; });
  $('#allI', el).onclick = () => { f.iAll = !f.iAll; render(); };
  bindItems(el); bindEmpty(el);
};

Views.facturas = (el) => {
  const q = (state.filters.fQ || '').toLowerCase();
  const F = Store.list('facturas').filter(x => !q || `${x.proveedor} ${x.numero} ${x.nit}`.toLowerCase().includes(q)).sort((a, b) => (b.fecha || '').localeCompare(a.fecha || ''));
  el.innerHTML = `
    <div class="capture">
      <button id="fCam"><span class="e">📷</span>Escanear con cámara</button>
      <button id="fFile"><span class="e">📎</span>Cargar archivo<small style="font-weight:500;color:var(--muted)">foto o PDF</small></button>
    </div>
    <div class="search">${ICON.search}<input id="fQ" placeholder="Buscar por proveedor, número o NIT" value="${esc(state.filters.fQ || '')}"></div>
    ${F.length ? `<div class="banner info">🗂️ <div><b>${F.length}</b> factura${F.length > 1 ? 's' : ''} · total <b>${money(sum(F, x => x.total))}</b></div></div>
      <div class="fact-grid">${F.map(x => `<div class="fact" data-fact="${x.id}"><div class="thumb">${x.adjunto?.tipo === 'imagen' && x.adjunto.data ? `<img src="${x.adjunto.data}" alt="">` : x.adjunto?.tipo === 'pdf' ? '📄' : '🧾'}</div>
        <div class="info"><b>${esc(x.proveedor || 'Factura')}</b><small>${x.numero ? '#' + esc(x.numero) + ' · ' : ''}${fmtDate(x.fecha)}</small><div style="font-weight:700;margin-top:2px">${money(x.total)}</div></div></div>`).join('')}</div>`
      : emptyBox('🧾', 'Sin facturas', 'Escanea tus facturas de insumos con la cámara o cárgalas desde tus archivos. Quedan guardadas y ligadas a tus gastos.', '', '')}`;
  $('#fCam', el).onclick = () => Forms.nuevaFactura('camera');
  $('#fFile', el).onclick = () => Forms.nuevaFactura('file');
  const inp = $('#fQ', el); inp.oninput = () => { state.filters.fQ = inp.value; const p = inp.selectionStart; render(); const n = $('#fQ'); n.focus(); n.setSelectionRange(p, p); };
  $$('[data-fact]', el).forEach(x => x.onclick = () => Forms.factura(Store.get('facturas', x.dataset.fact)));
};

Views.calendario = (el) => {
  const m = state.month; const sel = state.calSel;
  const first = new Date(m.getFullYear(), m.getMonth(), 1);
  const start = new Date(first); start.setDate(1 - ((first.getDay() + 6) % 7));
  const marks = {};
  const addMark = (d, color) => { (marks[d] = marks[d] || []).length < 6 && marks[d].push(color); };
  Store.list('eventos').forEach(e => addMark(e.fecha, evType(e.tipo).color));
  Store.list('gastos').forEach(g => addMark(g.fecha, '#A8743A'));
  Store.list('ingresos').forEach(i => addMark(i.fecha, '#6CC24A'));
  Store.list('trabajos').forEach(t => addMark(t.fecha, '#8C5A2B'));
  Store.list('pagos').forEach(p => addMark(p.fecha, '#1F7AB8'));
  let cells = '';
  for (let i = 0; i < 42; i++) {
    const d = new Date(start); d.setDate(start.getDate() + i); const k = isoDate(d);
    cells += `<button class="cal-day ${d.getMonth() !== m.getMonth() ? 'out' : ''} ${k === today() ? 'today' : ''} ${k === sel ? 'sel' : ''}" data-day="${k}">${d.getDate()}<span class="dots">${(marks[k] || []).map(c => `<i style="background:${c}"></i>`).join('')}</span></button>`;
    if (i >= 34 && d.getMonth() !== m.getMonth() && d.getDay() === 0) break;
  }
  const E = Store.list('eventos').filter(e => e.fecha === sel).sort((a, b) => (a.hora || '').localeCompare(b.hora || ''));
  const G = Store.list('gastos').filter(g => g.fecha === sel), I = Store.list('ingresos').filter(i => i.fecha === sel);
  const mesE = Store.list('eventos').filter(e => sameMonth(e.fecha, m));
  el.innerHTML = `
    <div class="card">
      <div class="cal-head"><h3>${monthLabel(m)}</h3><div class="nav"><button data-d="-1" aria-label="Anterior">${ICON.chevL}</button><button id="calToday" style="width:auto;padding:0 10px;font-weight:600;font-size:13px">Hoy</button><button data-d="1" aria-label="Siguiente">${ICON.chevR}</button></div></div>
      <div class="cal-grid">${DOW.map(d => `<div class="cal-dow">${d}</div>`).join('')}${cells}</div>
      <div class="cal-legend"><span><i style="background:#6CC24A"></i>Ingreso</span><span><i style="background:#A8743A"></i>Gasto</span><span><i style="background:#1E8E3E"></i>Labor</span><span><i style="background:#8C5A2B"></i>Trabajo</span><span><i style="background:#1F7AB8"></i>Pago</span><span>${mesE.filter(e => e.hecho).length}/${mesE.length} labores hechas este mes</span></div>
    </div>
    <div class="btn-row" style="margin-bottom:12px"><button class="btn sm" id="cE">📅 Labor</button><button class="btn sm" id="cG">🧾 Gasto</button><button class="btn sm" id="cI">🚚 Carga</button><button class="btn sm" id="cJ">👨‍🌾 Trabajo</button><button class="btn sm" id="cP">💵 Pago</button></div>
    <div id="dayRep">${dailyReportHTML(sel)}</div>`;
  $$('.cal-head .nav [data-d]', el).forEach(b => b.onclick = () => { state.month = new Date(m.getFullYear(), m.getMonth() + num(b.dataset.d), 1); render(); });
  $('#calToday', el).onclick = () => { const t = new Date(); state.month = new Date(t.getFullYear(), t.getMonth(), 1); state.calSel = today(); render(); };
  $$('[data-day]', el).forEach(b => b.onclick = () => { state.calSel = b.dataset.day; const d = parseDate(b.dataset.day); if (d.getMonth() !== m.getMonth()) state.month = new Date(d.getFullYear(), d.getMonth(), 1); render(); setTimeout(() => $('#dayRep')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60); });
  $('#cE', el).onclick = () => Forms.evento(null, { fecha: sel });
  $('#cG', el).onclick = () => Forms.gasto(null, { fecha: sel });
  $('#cI', el).onclick = () => Forms.ingreso(null, { fecha: sel });
  $('#cJ', el).onclick = () => Forms.trabajo(null, { fecha: sel });
  $('#cP', el).onclick = () => Forms.pago(null, { fecha: sel });
  bindItems(el); bindDailyReport(el, sel);
};

Views.informes = (el) => {
  const f = state.filters; const per = f.rPer || 'mes';
  const now = new Date();
  let from = '0000-00-00', to = '9999-99-99', label = 'Todo el tiempo';
  if (per === 'mes') { const d = state.month; from = isoDate(new Date(d.getFullYear(), d.getMonth(), 1)); to = isoDate(new Date(d.getFullYear(), d.getMonth() + 1, 0)); label = monthLabel(d); }
  if (per === 'anio') { from = `${now.getFullYear()}-01-01`; to = `${now.getFullYear()}-12-31`; label = 'Año ' + now.getFullYear(); }
  if (per === 'dia') {
    const dd = f.rDay || today();
    el.innerHTML = `<div class="chips">${[['dia', 'Día'], ['mes', 'Mes'], ['anio', 'Este año'], ['todo', 'Todo'], ['rango', 'Rango de fechas']].map(([k, n]) => `<button class="chip ${per === k ? 'on' : ''}" data-per="${k}">${n}</button>`).join('')}</div>
      <div class="card" style="padding:10px 14px;display:flex;align-items:center;gap:8px;justify-content:center"><button class="btn sm" data-dd="-1">${ICON.chevL}</button><input type="date" id="rDay" value="${dd}" style="border:1.5px solid var(--line);border-radius:12px;padding:8px 10px;background:var(--surface)"><button class="btn sm" data-dd="1">${ICON.chevR}</button></div>
      ${dailyReportHTML(dd)}`;
    $$('[data-per]', el).forEach(b => b.onclick = () => { f.rPer = b.dataset.per; render(); });
    $('#rDay', el).onchange = (e) => { f.rDay = e.target.value; render(); };
    $$('[data-dd]', el).forEach(b => b.onclick = () => { const x = parseDate(dd); x.setDate(x.getDate() + num(b.dataset.dd)); f.rDay = isoDate(x); render(); });
    bindDailyReport(el, dd); return;
  }
  if (per === 'rango') { from = f.rFrom || isoDate(new Date(now.getFullYear(), now.getMonth() - 2, 1)); to = f.rTo || today(); label = `${fmtDate(from)} – ${fmtDate(to)}`; }
  const inR = (x) => x.fecha >= from && x.fecha <= to && (!f.rLote || f.rLote === 'todos' || (x.lote || '') === f.rLote);
  const G = Store.list('gastos').filter(inR), I = Store.list('ingresos').filter(inR);
  const tg = sum(G, g => g.total), ti = sum(I, i => i.total), bal = ti - tg;
  const byCat = EXPENSE_CATEGORIES.map(c => ({ label: c.name, icon: c.icon, color: c.color, value: sum(G.filter(g => g.categoria === c.id), g => g.total) })).filter(r => r.value).sort((a, b) => b.value - a.value);
  const lotIds = [...new Set([...G, ...I].map(x => x.lote || ''))];
  const byLot = lotIds.map(id => ({ id, g: sum(G.filter(x => (x.lote || '') === id), x => x.total), i: sum(I.filter(x => (x.lote || '') === id), x => x.total) })).sort((a, b) => (b.g + b.i) - (a.g + a.i));
  // 12 meses
  const months = []; for (let k = 11; k >= 0; k--) { const d = new Date(now.getFullYear(), now.getMonth() - k, 1); months.push(d); }
  const lotF = (x) => !f.rLote || f.rLote === 'todos' || (x.lote || '') === f.rLote;
  const mData = months.map(d => ({ d, g: sum(Store.list('gastos').filter(x => lotF(x) && sameMonth(x.fecha, d)), x => x.total), i: sum(Store.list('ingresos').filter(x => lotF(x) && sameMonth(x.fecha, d)), x => x.total) }));
  const mMax = Math.max(1, ...mData.map(x => Math.max(x.g, x.i)));
  const prodR = {}; I.forEach(i => { const k = (i.producto || 'Producto'); const r = prodR[k] = prodR[k] || { n: 0, kg: 0, tot: 0, und: {} }; r.n++; r.kg += num(i.peso); r.tot += num(i.total); if (i.cantidad) r.und[i.unidad] = (r.und[i.unidad] || 0) + num(i.cantidad); });
  const TR = Store.list('trabajos').filter(inR), PG = Store.list('pagos').filter(p => p.fecha >= from && p.fecha <= to);
  const wkR = {}; TR.forEach(t => { const r = wkR[t.trabajador] = wkR[t.trabajador] || { jor: 0, tot: 0, pag: 0 }; if (/jornal|día/.test(t.unidad)) r.jor += t.unidad === 'medio jornal' ? num(t.cantidad) / 2 : num(t.cantidad); r.tot += num(t.total); }); PG.forEach(p => { const r = wkR[p.trabajador] = wkR[p.trabajador] || { jor: 0, tot: 0, pag: 0 }; r.pag += num(p.monto); });
  const pend = Store.list('gastos').filter(g => g.estado === 'Pendiente'), cobrar = Store.list('ingresos').filter(i => i.estado === 'Por cobrar');

  el.innerHTML = `
    <div class="chips">${[['dia', 'Día'], ['mes', 'Mes'], ['anio', 'Este año'], ['todo', 'Todo'], ['rango', 'Rango de fechas']].map(([k, n]) => `<button class="chip ${per === k ? 'on' : ''}" data-per="${k}">${n}</button>`).join('')}</div>
    ${per === 'mes' ? `<div class="card" style="padding:10px 14px;display:flex;justify-content:center"><div class="period" id="pR">${periodNav('pR').replace(/^<div class="period" id="pR">/, '').replace(/<\/div>$/, '')}</div></div>` : ''}
    ${per === 'rango' ? `<div class="grid2"><div class="field"><label>Desde</label><input type="date" id="rFrom" value="${from}"></div><div class="field"><label>Hasta</label><input type="date" id="rTo" value="${to}"></div></div>` : ''}
    <div class="field"><select id="rLote"><option value="todos">🌾 Todos los cultivos</option>${loteOptions(f.rLote, true)}</select></div>
    <div class="hero"><div class="hi">📊 ${esc(label)}</div><div class="bal-label">Ganancia / pérdida</div><div class="bal">${bal < 0 ? '-' : ''}${money(Math.abs(bal))}</div>
      <div class="row"><div class="pill"><small>Ingresos</small><b>${money(ti)}</b></div><div class="pill"><small>Gastos</small><b>${money(tg)}</b></div></div>
      <div class="row"><div class="pill"><small>Margen</small><b>${ti ? Math.round(bal / ti * 100) + '%' : '—'}</b></div><div class="pill"><small>Movimientos</small><b>${G.length + I.length}</b></div></div></div>
    <div class="card"><h3>💸 Gastos por tipo</h3>${barsHTML(byCat, tg)}</div>
    <div class="card"><h3>🌱 Por cultivo</h3>${byLot.length ? `<table class="tbl"><thead><tr><th>Cultivo</th><th class="r">Gastos</th><th class="r">Ingresos</th><th class="r">Balance</th></tr></thead><tbody>${byLot.map(r => `<tr><td>${loteIcon(r.id)} ${esc(loteName(r.id))}</td><td class="r neg">${moneyShort(r.g)}</td><td class="r pos">${moneyShort(r.i)}</td><td class="r ${r.i - r.g < 0 ? 'neg' : 'pos'}"><b>${moneyShort(r.i - r.g)}</b></td></tr>`).join('')}</tbody></table>` : '<div class="empty" style="padding:14px"><p>Sin datos</p></div>'}</div>
    <div class="card"><h3>🚚 Cosechas y ventas por producto</h3>${Object.keys(prodR).length ? `<div style="overflow-x:auto"><table class="tbl"><thead><tr><th>Producto</th><th class="r">Cantidad</th><th class="r">Peso</th><th class="r">Valor</th></tr></thead><tbody>${Object.entries(prodR).sort((a, b) => b[1].tot - a[1].tot).map(([k, r]) => `<tr><td>${esc(k)}<br><small style="color:var(--muted)">${r.n} registro${r.n > 1 ? 's' : ''}${r.kg && r.tot ? ' · prom. ' + money(r.tot / r.kg) + '/kg' : ''}</small></td><td class="r">${Object.entries(r.und).map(([u, v]) => qty(v) + ' ' + esc(u)).join('<br>') || '—'}</td><td class="r">${r.kg ? qty(r.kg) + ' kg' : '—'}</td><td class="r">${money(r.tot)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty" style="padding:14px"><p>Sin cosechas en este periodo</p></div>'}</div>
    <div class="card"><h3>👨‍🌾 Mano de obra por trabajador</h3>${Object.keys(wkR).length ? `<div style="overflow-x:auto"><table class="tbl"><thead><tr><th>Trabajador</th><th class="r">Jornales</th><th class="r">Trabajado</th><th class="r">Pagado</th></tr></thead><tbody>${Object.entries(wkR).map(([id, r]) => `<tr><td>${esc(workerName(id))}</td><td class="r">${r.jor ? qty(r.jor) : '—'}</td><td class="r">${money(r.tot)}</td><td class="r">${money(r.pag)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty" style="padding:14px"><p>Sin trabajos registrados en este periodo</p></div>'}</div>
    <div class="card"><h3>📈 Últimos 12 meses</h3><div class="cols">${mData.map(x => `<div class="col"><div class="pair"><i style="height:${(x.i / mMax * 100).toFixed(1)}%;background:var(--g500)" title="Ingresos ${money(x.i)}"></i><i style="height:${(x.g / mMax * 100).toFixed(1)}%;background:var(--soil-l)" title="Gastos ${money(x.g)}"></i></div><small>${MONTHS_S[x.d.getMonth()]}</small></div>`).join('')}</div>
      <div class="legend"><span><i style="background:var(--g500)"></i>Ingresos</span><span><i style="background:var(--soil-l)"></i>Gastos</span></div></div>
    <div class="card"><h3>⚖️ Cantidades utilizadas por tipo</h3>${quantityTable(G)}</div>
    ${pend.length || cobrar.length ? `<div class="card"><h3>⏳ Pendientes</h3>
      ${pend.length ? `<div class="total-box"><span>Por pagar (${pend.length})</span><b class="neg" style="color:var(--red)">${money(sum(pend, x => x.total))}</b></div>` : ''}
      ${cobrar.length ? `<div class="total-box"><span>Por cobrar (${cobrar.length})</span><b>${money(sum(cobrar, x => x.total))}</b></div>` : ''}</div>` : ''}
    <div class="card"><h3>📤 Exportar</h3><div class="btn-row"><button class="btn sm" id="xG">${ICON.download} Gastos CSV</button><button class="btn sm" id="xI">${ICON.download} Ventas CSV</button><button class="btn sm" id="xP">${ICON.download} Pagos CSV</button></div><p style="font-size:12.5px;color:var(--muted);margin:10px 0 0">Se abren en Excel o Google Sheets. Incluyen el periodo y cultivo seleccionados.</p></div>`;
  $$('[data-per]', el).forEach(b => b.onclick = () => { f.rPer = b.dataset.per; render(); });
  $$('#pR button', el).forEach(b => { b.style.background = 'var(--surface-2)'; b.style.color = 'var(--text)'; b.onclick = () => { state.month = new Date(state.month.getFullYear(), state.month.getMonth() + num(b.dataset.d), 1); render(); }; });
  if (per === 'rango') { $('#rFrom', el).onchange = (e) => { f.rFrom = e.target.value; render(); }; $('#rTo', el).onchange = (e) => { f.rTo = e.target.value; render(); }; }
  const sl = $('#rLote', el); if (!f.rLote || f.rLote === 'todos') sl.value = 'todos'; sl.onchange = () => { f.rLote = sl.value; render(); };
  $('#xG', el).onclick = () => saveFile(`TerraTech_gastos_${today()}.csv`, toCSV([['Fecha', 'Cultivo', 'Categoría', 'Tipo', 'Producto/Descripción', 'Cantidad', 'Unidad', 'Valor unitario', 'Total', 'Proveedor', 'Método de pago', 'Estado', 'Notas'], ...G.sort((a, b) => a.fecha.localeCompare(b.fecha)).map(g => [g.fecha, loteName(g.lote), cat(g.categoria).name, g.tipo, g.descripcion, g.cantidad, g.unidad, g.valorUnit, g.total, g.proveedor, g.metodo, g.estado, g.notas])]), 'text/csv');
  $('#xP', el).onclick = () => saveFile(`TerraTech_pagos_${today()}.csv`, toCSV([['Fecha', 'Hora', 'Trabajador', 'Concepto', 'Monto', 'Forma de pago', 'Lugar', 'Latitud', 'Longitud', 'Notas'], ...PG.sort((a, b) => a.fecha.localeCompare(b.fecha)).map(p => [p.fecha, p.hora, workerName(p.trabajador), p.concepto, p.monto, p.metodo, p.lugar, p.ubicacion?.lat, p.ubicacion?.lng, p.notas])]), 'text/csv');
  $('#xI', el).onclick = () => saveFile(`TerraTech_ingresos_${today()}.csv`, toCSV([['Fecha', 'Hora', 'Cultivo', 'Tipo', 'Viaje/carga', 'Producto', 'Cantidad', 'Empaque', 'Peso kg', 'Precio/kg', 'Precio/unidad', 'Total', 'Comprador', 'Vehículo', 'Destino', 'Lugar', 'Latitud', 'Longitud', 'Estado', 'Notas'], ...I.sort((a, b) => a.fecha.localeCompare(b.fecha)).map(i => [i.fecha, i.hora, loteName(i.lote), i.tipo, i.viaje, i.producto, i.cantidad, i.unidad, i.peso, i.precioKg, i.precioUnit, i.total, i.comprador, i.vehiculo, i.destino, i.lugar, i.ubicacion?.lat, i.ubicacion?.lng, i.estado, i.notas])]), 'text/csv');
};

Views.pqr = (el) => {
  const P = Store.list('pqr').sort((a, b) => b.creado.localeCompare(a.creado));
  el.innerHTML = `
    <div class="banner info">💬 <div><b>Peticiones, quejas, reclamos y sugerencias.</b><br>Cuéntanos qué mejorar o qué problema tuviste. Cada solicitud recibe un número de radicado y se responde en máximo 15 días hábiles.</div></div>
    <button class="btn primary block" id="newP" style="margin-bottom:14px">✍️ Nueva solicitud</button>
    ${P.length ? `<div class="section-title">Mis solicitudes</div><div class="card" style="padding:4px 14px"><div class="list">${P.map(p => `<div class="item" data-pqr="${p.id}"><div class="ic">${{ Petición: '📨', Queja: '😟', Reclamo: '⚠️', Sugerencia: '💡', Felicitación: '🌟' }[p.tipo] || '💬'}</div>
      <div class="mid"><b>${esc(p.asunto)}</b><small class="radicado">${esc(p.radicado)} · ${fmtDate(p.fecha)}</small></div><span class="tag ${p.estado === 'Respondida' ? '' : p.estado === 'Cerrada' ? 'soil' : 'gold'}">${esc(p.estado)}</span></div>`).join('')}</div></div>` : emptyBox('📭', 'Sin solicitudes', 'Aquí verás el historial de tus PQR.', '', '')}`;
  $('#newP', el).onclick = () => Forms.pqr();
  $$('[data-pqr]', el).forEach(x => x.onclick = () => Forms.verPqr(Store.get('pqr', x.dataset.pqr)));
};

Views.mas = (el) => {
  const tiles = [
    ['trabajadores', '👨‍🌾', 'Trabajadores', 'Jornales y pagos'],
    ['ingresos', '🚚', 'Cargas y ventas', 'Peso, precio y recolección'],
    ['facturas', '🧾', 'Facturas', 'Escanear o cargar'],
    ['informes', '📊', 'Informes', 'Balance y cantidades'],
    ['catalogo', '📚', 'Catálogo de cultivos', `${CROPS.length - 1}+ cultivos`],
    ['pqr', '💬', 'PQR', 'Peticiones, quejas y reclamos'],
    ['perfil', '👤', 'Mi perfil', 'Finca, cuenta y respaldo'],
    ['autor', '👑', 'Derechos de autor', 'Firma y licencia']
  ];
  el.innerHTML = `
    <div class="card" style="display:flex;align-items:center;gap:12px"><div class="lot-ic" style="width:52px;height:52px;border-radius:16px;font-size:24px;display:grid;place-items:center;background:linear-gradient(135deg,var(--g700),var(--g400));color:#fff;font-weight:800">${esc((Store.user.name || '?').slice(0, 1).toUpperCase())}</div>
      <div style="flex:1;min-width:0"><b style="font-size:16px">${esc(Store.user.name)}</b><br><small style="color:var(--muted)">${esc(Store.user.email)}</small></div></div>
    <div class="menu-grid">${tiles.map(([k, e, t, s]) => `<button class="menu-tile" data-go2="${k}"><span class="e">${e}</span><b>${t}</b><small>${s}</small></button>`).join('')}
      <button class="menu-tile" id="mLogout"><span class="e">🚪</span><b>Cerrar sesión</b><small>Salir de la cuenta</small></button></div>
    <div class="foot-copy">TerraTech v${APP.version}<br>${copyrightLine()}</div>`;
  $$('[data-go2]', el).forEach(b => b.onclick = () => go(b.dataset.go2));
  $('#mLogout', el).onclick = async () => { if (await confirmBox('¿Cerrar sesión en este teléfono?', 'Cerrar sesión')) Store.logout(); };
};

Views.catalogo = (el) => {
  const g = state.filters.catG || ''; const q = (state.filters.catQ || '').toLowerCase();
  const list = allCrops().filter(c => (!g || c.group === g) && (!q || c.name.toLowerCase().includes(q)));
  el.innerHTML = `
    <div class="search">${ICON.search}<input id="catQ" placeholder="Buscar entre ${allCrops().length} cultivos" value="${esc(state.filters.catQ || '')}"></div>
    <div class="chips"><button class="chip ${!g ? 'on' : ''}" data-g="">Todos</button>${CROP_GROUPS.map(x => `<button class="chip ${g === x.id ? 'on' : ''}" data-g="${x.id}">${x.name}</button>`).join('')}</div>
    <div class="crop-grid">${list.map(c => `<button class="crop-opt" data-crop="${c.id}"><span class="e">${c.icon}</span>${esc(c.name)}${c.propio ? '<small style="color:var(--g600)">propio</small>' : ''}</button>`).join('')}</div>
    <p style="font-size:13px;color:var(--muted);text-align:center;margin-top:16px">Toca un cultivo para crear un lote. ¿No está el tuyo? Usa el botón + para crear un cultivo personalizado.</p>`;
  const inp = $('#catQ', el); inp.oninput = () => { state.filters.catQ = inp.value; const p = inp.selectionStart; render(); const n = $('#catQ'); n.focus(); n.setSelectionRange(p, p); };
  $$('[data-g]', el).forEach(b => b.onclick = () => { state.filters.catG = b.dataset.g; render(); });
  $$('[data-crop]', el).forEach(b => b.onclick = () => b.dataset.crop === 'otro' ? Forms.cultivoPropio() : Forms.lote(null, { cultivo: b.dataset.crop }));
};

Views.perfil = (el) => {
  const p = Store.profile; const theme = localStorage.getItem('tt_theme') || 'auto';
  const saved = Store.savedEmails.list();
  el.innerHTML = `
    <div class="card"><h3>👤 Datos personales y de la finca</h3>
      <div class="field"><label>Nombre</label><input id="pNom" value="${esc(Store.user.name)}"></div>
      <div class="field"><label>Correo</label><input value="${esc(Store.user.email)}" disabled></div>
      <div class="field"><label>Nombre de la finca</label><input id="pFin" value="${esc(p.finca || '')}" placeholder="Ej: Finca La Esperanza"></div>
      <div class="grid2"><div class="field"><label>Municipio</label><input id="pMun" value="${esc(p.municipio || '')}"></div><div class="field"><label>Vereda</label><input id="pVer" value="${esc(p.vereda || '')}"></div></div>
      <div class="grid2"><div class="field"><label>Área total (ha)</label><input id="pArea" type="number" inputmode="decimal" value="${esc(p.areaTotal || '')}"></div><div class="field"><label>Teléfono</label><input id="pTel" type="tel" value="${esc(p.telefono || '')}"></div></div>
      <button class="btn primary block" id="pSave">Guardar cambios</button></div>
    <div class="card"><h3>☁️ Servidor y sincronización</h3>
      <p style="margin:0 0 6px">${Store.mode === 'firebase' ? '✅ Conectado al servidor. Tus datos se sincronizan en todos los teléfonos donde inicies sesión con este correo, y funcionan sin internet.' : '📱 Modo local: los datos se guardan solo en este teléfono. Para sincronizar, configura Firebase (ver README del proyecto).'}</p></div>
    <div class="card"><h3>🎨 Apariencia</h3><div class="chips">${[['auto', 'Automático'], ['light', 'Claro'], ['dark', 'Oscuro']].map(([k, n]) => `<button class="chip ${theme === k ? 'on' : ''}" data-th="${k}">${n}</button>`).join('')}</div></div>
    <div class="card"><h3>📧 Correos guardados</h3><p style="margin:0 0 10px;color:var(--muted);font-size:13.5px">Se muestran en la pantalla de inicio de sesión para entrar más rápido.</p>
      ${saved.length ? saved.map(e => `<div class="item" style="cursor:default"><div class="ic">📧</div><div class="mid"><b>${esc(e)}</b></div><button class="btn sm danger" data-rm="${esc(e)}">Quitar</button></div>`).join('') : '<p style="color:var(--muted);margin:0">No hay correos guardados.</p>'}</div>
    <div class="card"><h3>🔐 Cambiar contraseña</h3>
      <div class="field"><label>Contraseña actual</label><input id="pOld" type="password" autocomplete="current-password"></div>
      <div class="field"><label>Nueva contraseña</label><input id="pNew" type="password" autocomplete="new-password"></div>
      <button class="btn block" id="pPass">Actualizar contraseña</button></div>
    <div class="card"><h3>💾 Respaldo</h3><p style="margin:0 0 10px;color:var(--muted);font-size:13.5px">Descarga una copia de todos tus datos o restaura una copia anterior.</p>
      <div class="btn-row"><button class="btn sm" id="pExp">${ICON.download} Descargar respaldo</button><button class="btn sm" id="pImp">Restaurar respaldo</button></div></div>
    <button class="btn danger block" id="pOut">Cerrar sesión</button>
    <div class="foot-copy">${copyrightLine()}</div>`;
  $('#pSave', el).onclick = async () => { await Store.saveProfile({ nombre: $('#pNom').value.trim() || Store.user.name, finca: $('#pFin').value.trim(), municipio: $('#pMun').value.trim(), vereda: $('#pVer').value.trim(), areaTotal: $('#pArea').value, telefono: $('#pTel').value.trim() }); toast('Perfil guardado'); render(); };
  $$('[data-th]', el).forEach(b => b.onclick = () => { setTheme(b.dataset.th); render(); });
  $$('[data-rm]', el).forEach(b => b.onclick = () => { Store.savedEmails.remove(b.dataset.rm); render(); });
  $('#pPass', el).onclick = async () => { const o = $('#pOld').value, n = $('#pNew').value; if (n.length < 6) return toast('La nueva contraseña debe tener al menos 6 caracteres', true); try { await Store.changePassword(o, n); toast('Contraseña actualizada'); render(); } catch (e) { toast(authError(e), true); } };
  $('#pExp', el).onclick = () => saveFile(`TerraTech_respaldo_${today()}.json`, JSON.stringify(Store.exportAll(), null, 1), 'application/json');
  $('#pImp', el).onclick = async () => { const f = await pickFile('backup'); if (!f) return; try { const n = await Store.importAll(JSON.parse(await f.text())); toast(`Respaldo restaurado: ${n} registros`); } catch (e) { toast(e.message || 'Archivo inválido', true); } };
  $('#pOut', el).onclick = async () => { if (await confirmBox('¿Cerrar sesión en este teléfono?', 'Cerrar sesión')) Store.logout(); };
};

Views.autor = (el) => {
  el.innerHTML = `<div class="card author">
    <img src="img/logo.png" alt="TerraTech" style="width:84px;height:84px">
    <div class="brand-word" style="font-size:28px"><span class="t1">Terra</span><span class="t2">Tech</span></div>
    <div style="color:var(--muted);font-size:13px">Versión ${APP.version} · Cuentas del campo</div>
    ${sealSVG()}
    <div class="sig">${APP.author}</div>
    <div style="font-weight:700">Autor y desarrollador</div>
    <div style="color:var(--muted);font-size:13.5px">${copyrightLine()}</div>
    <div class="legal">
      <p><b>Derechos de autor.</b> TerraTech, su código fuente, diseño, logotipo, nombre, textos e interfaz son obra original de <b>${APP.author}</b> y están protegidos por la Ley 23 de 1982, la Decisión Andina 351 de 1993 y demás normas colombianas e internacionales sobre derecho de autor.</p>
      <p><b>Uso permitido.</b> Se concede al usuario una licencia personal, no exclusiva e intransferible para usar la aplicación. Queda prohibida la reproducción, distribución, modificación, ingeniería inversa o comercialización total o parcial sin autorización escrita del autor.</p>
      <p><b>Datos personales.</b> La información que registras (cuentas, cultivos, facturas) es tuya. Se usa únicamente para el funcionamiento de la aplicación, conforme a la Ley 1581 de 2012 de protección de datos personales. Puedes descargarla o solicitar su eliminación mediante una PQR.</p>
      <p><b>Contacto.</b> Para autorizaciones, licencias o soporte, usa el módulo de PQR.</p>
    </div></div>`;
};

/* ---------------- Formularios ---------------- */
const Forms = {};

Forms.pickCrop = (current, cb) => {
  let g = '', q = '';
  const draw = () => {
    const list = allCrops().filter(c => (!g || c.group === g) && (!q || c.name.toLowerCase().includes(q.toLowerCase())));
    $('#cpGrid').innerHTML = list.map(c => `<button class="crop-opt ${c.id === current ? 'on' : ''}" data-c="${c.id}"><span class="e">${c.icon}</span>${esc(c.name)}</button>`).join('');
    $$('#cpGrid [data-c]').forEach(b => b.onclick = () => { if (b.dataset.c === 'otro') { Forms.cultivoPropio(cb); return; } cb(b.dataset.c); });
  };
  Sheet.open('Elige el cultivo', `
    <div class="search">${ICON.search}<input id="cpQ" placeholder="Buscar: plátano, maíz, café…"></div>
    <div class="chips"><button class="chip on" data-g="">Todos</button>${CROP_GROUPS.map(x => `<button class="chip" data-g="${x.id}">${x.name}</button>`).join('')}</div>
    <div class="crop-grid" id="cpGrid"></div>`, b => {
    $('#cpQ', b).oninput = (e) => { q = e.target.value; draw(); };
    $$('[data-g]', b).forEach(x => x.onclick = () => { g = x.dataset.g; $$('[data-g]', b).forEach(y => y.classList.toggle('on', y === x)); draw(); });
    draw();
  });
};

Forms.cultivoPropio = (cb) => {
  Sheet.open('Nuevo cultivo personalizado', `
    <div class="field"><label>Nombre del cultivo</label><input id="cpN" placeholder="Ej: Ahuyamín, Chontaduro, Sacha inchi"></div>
    <div class="grid2"><div class="field"><label>Ícono (emoji)</label><input id="cpI" value="🌱" maxlength="4"></div>
    <div class="field"><label>Grupo</label><select id="cpG">${CROP_GROUPS.map(x => `<option value="${x.id}" ${x.id === 'otros' ? 'selected' : ''}>${x.name}</option>`).join('')}</select></div></div>
    <div class="field"><label>Unidad de cosecha</label><select id="cpU">${opts(HARVEST_UNITS, 'kg')}</select></div>
    <button class="btn primary block" id="cpS">Guardar cultivo</button>`, b => {
    $('#cpS', b).onclick = async () => {
      const name = $('#cpN').value.trim(); if (!name) return toast('Escribe el nombre del cultivo', true);
      const c = await Store.add('cultivosPropios', { id: 'p-' + name.toLowerCase().normalize('NFD').replace(/[^\w]+/g, '-') + '-' + Date.now().toString(36).slice(-3), name, icon: $('#cpI').value || '🌱', group: $('#cpG').value, unit: $('#cpU').value });
      toast('Cultivo agregado al catálogo');
      if (cb) cb(c.id); else Forms.lote(null, { cultivo: c.id });
    };
  });
};

Forms.lote = (l, preset = {}) => {
  if (!l && !preset.cultivo) { Forms.pickCrop(null, (id) => Forms.lote(null, { ...preset, cultivo: id })); return; }
  const d = l || { cultivo: preset.cultivo, estado: 'Sembrado', unidadArea: 'ha', siembra: today() };
  const c = crop(d.cultivo);
  const count = Store.list('lotes').filter(x => x.cultivo === d.cultivo).length;
  Sheet.open(l ? 'Editar cultivo' : 'Nuevo cultivo', `
    <button class="crop-opt on" id="lCrop" style="width:100%;flex-direction:row;justify-content:flex-start;gap:12px;padding:12px 14px;margin-bottom:13px;font-size:15px"><span class="e">${c.icon}</span><span style="flex:1;text-align:left">${esc(c.name)}<br><small style="color:var(--muted);font-weight:500">Tocar para cambiar</small></span>${ICON.chevR}</button>
    <div class="field"><label>Nombre del lote</label><input id="lNom" value="${esc(d.nombre || `${c.name} ${count + 1}`)}" placeholder="Ej: Lote de la quebrada"></div>
    <div class="grid3"><div class="field"><label>Área</label><input id="lArea" type="number" inputmode="decimal" value="${esc(d.area || '')}" placeholder="0"></div>
      <div class="field"><label>Unidad</label><select id="lUA">${opts(['ha', 'm²', 'fanegada', 'cuadra'], d.unidadArea)}</select></div></div>
    <div class="field"><label>Número de plantas / sitios</label><input id="lPl" type="number" inputmode="numeric" value="${esc(d.plantas || '')}" placeholder="Opcional"></div>
    <div class="grid2"><div class="field"><label>Fecha de siembra</label><input id="lSi" type="date" value="${esc(d.siembra || '')}"></div>
      <div class="field"><label>Cosecha estimada</label><input id="lCo" type="date" value="${esc(d.cosechaEst || '')}"></div></div>
    <div class="grid2"><div class="field"><label>Estado</label><select id="lEs">${opts(LOT_STATES, d.estado)}</select></div>
      <div class="field"><label>Vereda / ubicación</label><input id="lVe" value="${esc(d.vereda || '')}"></div></div>
    <div class="field"><label>Variedad y notas</label><textarea id="lNo" placeholder="Ej: Hartón, distancia 3x3, riego por goteo">${esc(d.notas || '')}</textarea></div>
    ${!l ? `<label class="check" style="color:var(--text)"><input type="checkbox" id="lEv" checked> Agregar la siembra al calendario</label>` : ''}
    <button class="btn primary block" id="lSave">${l ? 'Guardar cambios' : 'Crear cultivo'}</button>
    ${l ? '<button class="btn danger block" id="lDel" style="margin-top:10px">Eliminar cultivo</button>' : ''}`, b => {
    let cultivo = d.cultivo;
    $('#lCrop', b).onclick = () => {
      const keep = { ...d, nombre: $('#lNom').value, area: $('#lArea').value, unidadArea: $('#lUA').value, plantas: $('#lPl').value, siembra: $('#lSi').value, cosechaEst: $('#lCo').value, estado: $('#lEs').value, vereda: $('#lVe').value, notas: $('#lNo').value };
      Forms.pickCrop(cultivo, (id) => { const nc = crop(id); if (!l && keep.nombre.startsWith(crop(cultivo).name)) keep.nombre = ''; Forms.lote(l ? { ...l, ...keep, cultivo: id } : null, { ...keep, cultivo: id }); });
    };
    if (!l && preset.nombre !== undefined) { $('#lNom').value = preset.nombre || `${c.name} ${count + 1}`; ['area', 'plantas', 'siembra', 'cosechaEst', 'vereda', 'notas'].forEach(() => {}); }
    $('#lSave', b).onclick = async () => {
      const data = { cultivo, nombre: $('#lNom').value.trim() || c.name, area: $('#lArea').value, unidadArea: $('#lUA').value, plantas: $('#lPl').value, siembra: $('#lSi').value, cosechaEst: $('#lCo').value, estado: $('#lEs').value, vereda: $('#lVe').value.trim(), notas: $('#lNo').value.trim() };
      try {
        if (l) { await Store.update('lotes', l.id, data); toast('Cultivo actualizado'); }
        else {
          const nl = await Store.add('lotes', data);
          if ($('#lEv')?.checked && data.siembra) await Store.add('eventos', { tipo: 'siembra', titulo: `Siembra de ${c.name}`, fecha: data.siembra, lote: nl.id, hecho: data.siembra <= today() });
          if (data.cosechaEst) await Store.add('eventos', { tipo: 'cosecha', titulo: `Cosecha estimada · ${data.nombre}`, fecha: data.cosechaEst, lote: nl.id, hecho: false });
          toast('Cultivo creado 🌱');
          Sheet.close(); go('lote', { id: nl.id }); return;
        }
        Sheet.close(); render();
      } catch (e) { toast(authError(e), true); }
    };
    if (l) $('#lDel', b).onclick = async () => {
      if (!await confirmBox(`¿Eliminar "${l.nombre}"? Los gastos e ingresos quedarán como "General".`)) return;
      await Store.remove('lotes', l.id); toast('Cultivo eliminado'); go('cultivos');
    };
  });
  // restaurar valores al cambiar de cultivo en lote nuevo
  if (!l && preset.area !== undefined) {
    $('#lArea').value = preset.area || ''; $('#lUA').value = preset.unidadArea || 'ha'; $('#lPl').value = preset.plantas || ''; $('#lSi').value = preset.siembra || ''; $('#lCo').value = preset.cosechaEst || ''; $('#lEs').value = preset.estado || 'Sembrado'; $('#lVe').value = preset.vereda || ''; $('#lNo').value = preset.notas || '';
  }
};

Forms.gasto = (g, preset = {}) => {
  const d = g || { fecha: preset.fecha || today(), lote: preset.lote ?? (state.view === 'lote' ? state.params.id : ''), categoria: preset.categoria || 'insumos', estado: 'Pagado', metodo: 'Efectivo', ...preset };
  let attach = null; // adjunto nuevo pendiente
  const fact = g?.facturaId ? Store.get('facturas', g.facturaId) : null;
  const allUnits = [...new Set(EXPENSE_CATEGORIES.flatMap(c => c.units))];
  Sheet.open(g ? 'Editar gasto' : 'Nuevo gasto', `
    <div class="grid2"><div class="field"><label>Fecha</label><input type="date" id="gF" value="${esc(d.fecha)}"></div><div class="field"><label>Hora</label><input type="time" id="gH" value="${esc(d.hora || (g ? '' : nowTime()))}"></div></div>
    <div class="field"><label>Cultivo</label><select id="gL">${loteOptions(d.lote || '')}</select></div>
    <div class="field"><label>Tipo de gasto</label><select id="gC">${EXPENSE_CATEGORIES.map(c => `<option value="${c.id}" ${c.id === d.categoria ? 'selected' : ''}>${c.icon} ${c.name}</option>`).join('')}</select></div>
    <div class="field"><label>Clase</label><select id="gT"></select><input id="gTo" placeholder="Escribe la clase" style="margin-top:8px" hidden></div>
    <div class="field"><label>Producto o descripción</label><input id="gD" value="${esc(d.descripcion || '')}" placeholder="Ej: Triple 15, Urea, jornal de desyerba" list="gDl"><datalist id="gDl">${[...new Set(Store.list('gastos').map(x => x.descripcion).filter(Boolean))].slice(0, 40).map(x => `<option value="${esc(x)}">`).join('')}</datalist></div>
    <div class="grid3"><div class="field"><label>Cantidad</label><input id="gQ" type="number" inputmode="decimal" value="${esc(d.cantidad || '')}" placeholder="0"></div>
      <div class="field"><label>Unidad</label><select id="gU"></select></div></div>
    <div class="grid2"><div class="field"><label>Valor unitario</label><input id="gVU" type="number" inputmode="numeric" value="${esc(d.valorUnit || '')}" placeholder="$"></div>
      <div class="field"><label>Valor total</label><input id="gVT" type="number" inputmode="numeric" value="${esc(d.total || '')}" placeholder="$"></div></div>
    <div class="total-box"><span>Total del gasto</span><b id="gTot">${money(d.total || 0)}</b></div>
    <div class="field"><label>Proveedor / almacén</label><input id="gP" value="${esc(d.proveedor || '')}" list="gPl" placeholder="Ej: Agroinsumos El Campo"><datalist id="gPl">${[...new Set(Store.list('gastos').map(x => x.proveedor).filter(Boolean))].map(x => `<option value="${esc(x)}">`).join('')}</datalist></div>
    <div class="grid2"><div class="field"><label>Forma de pago</label><select id="gM">${opts(PAY_METHODS, d.metodo)}</select></div>
      <div class="field"><label>Estado</label><select id="gE">${opts(['Pagado', 'Pendiente'], d.estado)}</select></div></div>
    <div class="field"><label>Factura</label>
      <div id="gFact">${fact ? `<div class="item" id="gOpenF"><div class="ic">${fact.adjunto?.tipo === 'imagen' && fact.adjunto.data ? `<img src="${fact.adjunto.data}">` : '🧾'}</div><div class="mid"><b>${esc(fact.proveedor || 'Factura')}</b><small>Ver factura adjunta</small></div>${ICON.chevR}</div>` : `<div class="btn-row"><button class="btn sm" id="gCam">📷 Escanear</button><button class="btn sm" id="gFile">📎 Adjuntar archivo</button></div>`}</div></div>
    <div class="field"><label>Notas</label><textarea id="gN" placeholder="Dosis, lote aplicado, observaciones">${esc(d.notas || '')}</textarea></div>
    <button class="btn primary block" id="gS">${g ? 'Guardar cambios' : 'Guardar gasto'}</button>
    ${g ? '<button class="btn danger block" id="gX" style="margin-top:10px">Eliminar gasto</button>' : ''}`, b => {
    const fillSubs = (keep) => {
      const c = cat($('#gC').value);
      const subs = [...c.subs]; if (keep && !subs.includes(keep)) subs.push(keep);
      $('#gT').innerHTML = subs.map(s => `<option ${s === keep ? 'selected' : ''}>${esc(s)}</option>`).join('') + '<option value="__otro">➕ Otra…</option>';
      const units = [...new Set([...c.units, ...allUnits])];
      const u = d.unidad && $('#gU').dataset.init !== '1' ? d.unidad : c.units[0];
      $('#gU').innerHTML = units.map(x => `<option ${x === u ? 'selected' : ''}>${x}</option>`).join('');
      $('#gU').dataset.init = '1';
    };
    fillSubs(d.tipo);
    $('#gC', b).onchange = () => { fillSubs(); $('#gTo').hidden = true; };
    $('#gT', b).onchange = () => { $('#gTo').hidden = $('#gT').value !== '__otro'; if (!$('#gTo').hidden) $('#gTo').focus(); };
    const upd = (src) => {
      const q = num($('#gQ').value), vu = num($('#gVU').value), vt = num($('#gVT').value);
      if (src !== 'vt' && q && vu) $('#gVT').value = Math.round(q * vu);
      if (src === 'vt' && q && vt) $('#gVU').value = Math.round(vt / q);
      $('#gTot').textContent = money($('#gVT').value);
    };
    $('#gQ', b).oninput = () => upd('q'); $('#gVU', b).oninput = () => upd('vu'); $('#gVT', b).oninput = () => upd('vt');
    const takeFile = async (kind) => {
      const f = await pickFile(kind); if (!f) return;
      attach = await fileToAttachment(f); if (!attach) return;
      $('#gFact').innerHTML = `<div class="item" style="cursor:default"><div class="ic">${attach.tipo === 'imagen' ? `<img src="${attach.data}">` : '📄'}</div><div class="mid"><b>${esc(attach.nombre)}</b><small>Se guardará con el gasto</small></div><button class="btn sm" id="gRmA">${ICON.x}</button></div>`;
      $('#gRmA').onclick = () => { attach = null; Forms.gasto(g, collect()); };
    };
    if ($('#gCam', b)) { $('#gCam', b).onclick = () => takeFile('camera'); $('#gFile', b).onclick = () => takeFile('file'); }
    if ($('#gOpenF', b)) $('#gOpenF', b).onclick = () => Forms.factura(fact);
    const collect = () => ({
      fecha: $('#gF').value || today(), hora: $('#gH').value, lote: $('#gL').value, categoria: $('#gC').value,
      tipo: $('#gT').value === '__otro' ? ($('#gTo').value.trim() || 'Otro') : $('#gT').value,
      descripcion: $('#gD').value.trim(), cantidad: $('#gQ').value, unidad: $('#gU').value, valorUnit: $('#gVU').value,
      total: num($('#gVT').value) || Math.round(num($('#gQ').value) * num($('#gVU').value)),
      proveedor: $('#gP').value.trim(), metodo: $('#gM').value, estado: $('#gE').value, notas: $('#gN').value.trim()
    });
    $('#gS', b).onclick = async () => {
      const data = collect();
      if (!data.total) return toast('Escribe el valor del gasto', true);
      const btn = $('#gS'); btn.disabled = true; btn.textContent = 'Guardando…';
      try {
        let saved = g ? await Store.update('gastos', g.id, data) : await Store.add('gastos', data);
        if (attach) {
          const f = await Store.add('facturas', { adjunto: attach, proveedor: data.proveedor, fecha: data.fecha, total: data.total, lote: data.lote, categoria: data.categoria, gastoId: saved.id, notas: data.descripcion });
          await Store.update('gastos', saved.id, { facturaId: f.id });
        }
        toast(g ? 'Gasto actualizado' : 'Gasto registrado ✅'); Sheet.close(); render();
      } catch (e) { btn.disabled = false; btn.textContent = 'Guardar gasto'; toast(authError(e), true); }
    };
    if (g) $('#gX', b).onclick = async () => { if (await confirmBox('¿Eliminar este gasto?')) { await Store.remove('gastos', g.id); toast('Gasto eliminado'); render(); } };
  });
};

Forms.ingreso = (i, preset = {}) => {
  const lt = lote(i?.lote ?? preset.lote ?? (state.view === 'lote' ? state.params.id : ''));
  const d = i || { fecha: preset.fecha || today(), hora: nowTime(), lote: lt?.id || '', tipo: preset.tipo || 'Venta de cosecha', estado: 'Pagado', producto: lt ? crop(lt.cultivo).name : '', unidad: lt ? crop(lt.cultivo).unit : 'bulto', base: 'kg', ...preset };
  let modo = d.tipo === 'Recolección' ? 'rec' : 'venta';
  const nextTrip = () => { const n = Store.list('ingresos').filter(x => x.fecha === ($('#iF')?.value || d.fecha) && x.viaje).length; return String(n + 1); };
  const W = Store.list('trabajadores').filter(w => w.activo !== false);
  Sheet.open(i ? 'Editar registro' : 'Cosecha, carga o venta', `
    <div class="tabs-auth" style="margin-bottom:14px"><button data-m="venta" class="${modo === 'venta' ? 'on' : ''}">🚚 Carga / venta</button><button data-m="rec" class="${modo === 'rec' ? 'on' : ''}">🧺 Recolección</button></div>
    <div class="grid2"><div class="field"><label>Fecha</label><input type="date" id="iF" value="${esc(d.fecha)}"></div><div class="field"><label>Hora</label><input type="time" id="iH" value="${esc(d.hora || '')}"></div></div>
    <div class="grid2"><div class="field"><label>Cultivo</label><select id="iL">${loteOptions(d.lote || '')}</select></div><div class="field"><label>Producto</label><input id="iP" value="${esc(d.producto || '')}" placeholder="Ej: Plátano hartón"></div></div>
    <div class="v-only grid2"><div class="field"><label>Tipo</label><select id="iT">${opts(INCOME_TYPES.filter(x => x !== 'Recolección'), d.tipo === 'Recolección' ? 'Venta de cosecha' : d.tipo)}</select></div><div class="field"><label>N.º de viaje / carga</label><input id="iV" value="${esc(d.viaje || '')}" placeholder="1"></div></div>
    <div class="grid3"><div class="field"><label>Cantidad de empaques</label><input id="iQ" type="number" inputmode="decimal" value="${esc(d.cantidad || '')}" placeholder="0"></div><div class="field"><label>Empaque</label><select id="iU">${opts([...new Set([d.unidad, ...PACK_UNITS].filter(Boolean))], d.unidad)}</select></div></div>
    <div class="field"><label>Peso total (kg)</label><input id="iKg" type="number" inputmode="decimal" value="${esc(d.peso || '')}" placeholder="Peso en báscula"><div class="hint" id="iKgH"></div></div>
    <div class="v-only">
      <div class="field"><label>¿Cómo se vendió?</label><select id="iB">${SALE_BASES.map(b => `<option value="${b.id}" ${b.id === (d.base || 'kg') ? 'selected' : ''}>${b.name}</option>`).join('')}</select></div>
      <div class="grid2"><div class="field"><label id="iPrL">Precio</label><input id="iPr" type="number" inputmode="numeric" value="${esc(d.base === 'unidad' ? d.precioUnit : d.base === 'total' ? d.total : d.precioKg || '')}" placeholder="$"></div><div class="field"><label>Valor total</label><input id="iVT" type="number" inputmode="numeric" value="${esc(d.total || '')}" placeholder="$" readonly></div></div>
      <div class="total-box"><span>Total de la venta</span><b id="iTot">${money(d.total || 0)}</b></div>
      <div class="hint" id="iAvg" style="margin:-6px 0 12px"></div>
      <div class="grid2"><div class="field"><label>Comprador</label><input id="iC" value="${esc(d.comprador || '')}" list="iCl" placeholder="Ej: Intermediario"><datalist id="iCl">${[...new Set(Store.list('ingresos').map(x => x.comprador).filter(Boolean))].map(x => `<option value="${esc(x)}">`).join('')}</datalist></div><div class="field"><label>Estado</label><select id="iE">${opts(['Pagado', 'Por cobrar'], d.estado)}</select></div></div>
      <div class="grid2"><div class="field"><label>Vehículo / placa</label><input id="iVeh" value="${esc(d.vehiculo || '')}" placeholder="Ej: Camión SXT-123"></div><div class="field"><label>Conductor</label><input id="iCond" value="${esc(d.conductor || '')}"></div></div>
      <div class="field"><label>Destino</label><input id="iDest" value="${esc(d.destino || '')}" placeholder="Ej: Corabastos, plaza de Tunja"></div>
    </div>
    <div class="r-only field"><label>Recolectado por</label><select id="iRec"><option value="">—</option>${W.map(w => `<option value="${w.id}" ${w.id === d.recolector ? 'selected' : ''}>${esc(w.nombre)}</option>`).join('')}</select></div>
    ${locFieldHTML('i', d)}
    <div class="field"><label>Notas</label><textarea id="iN" placeholder="Calidad, clasificación, observaciones">${esc(d.notas || '')}</textarea></div>
    <button class="btn primary block" id="iS">${i ? 'Guardar cambios' : 'Guardar'}</button>
    ${i ? '<button class="btn danger block" id="iX" style="margin-top:10px">Eliminar</button>' : ''}`, b => {
    const getLoc = bindLoc('i', d);
    const setModo = (m) => { modo = m; $$('[data-m]', b).forEach(x => x.classList.toggle('on', x.dataset.m === m)); $$('.v-only', b).forEach(x => x.hidden = m !== 'venta'); $$('.r-only', b).forEach(x => x.hidden = m !== 'rec'); if (m === 'venta' && !$('#iV').value && !i) $('#iV').value = nextTrip(); };
    $$('[data-m]', b).forEach(x => x.onclick = () => setModo(x.dataset.m));
    const calc = () => {
      const q = num($('#iQ').value), kg = num($('#iKg').value), pr = num($('#iPr').value), base = $('#iB').value;
      $('#iPrL').textContent = base === 'kg' ? 'Precio por kg' : base === 'unidad' ? `Precio por ${$('#iU').value}` : 'Valor total recibido';
      const tot = base === 'kg' ? Math.round(kg * pr) : base === 'unidad' ? Math.round(q * pr) : Math.round(pr);
      $('#iVT').value = tot || ''; $('#iTot').textContent = money(tot);
      $('#iKgH').textContent = q && kg ? `Promedio: ${qty(kg / q)} kg por ${$('#iU').value}` : '';
      $('#iAvg').textContent = tot && kg ? `Equivale a ${money(tot / kg)} por kg${q ? ` · ${money(tot / q)} por ${$('#iU').value}` : ''}` : '';
    };
    ['#iQ', '#iKg', '#iPr'].forEach(s => $(s, b).oninput = calc); $('#iB', b).onchange = calc; $('#iU', b).onchange = calc;
    $('#iL', b).onchange = () => { const l = lote($('#iL').value); if (!l) return; if (!$('#iP').value) $('#iP').value = crop(l.cultivo).name; const u = crop(l.cultivo).unit; if (![...$('#iU').options].some(o => o.value === u)) $('#iU').insertAdjacentHTML('afterbegin', `<option>${u}</option>`); $('#iU').value = u; calc(); };
    setModo(modo); calc();
    $('#iS', b).onclick = async () => {
      calc();
      const base = $('#iB').value, q = num($('#iQ').value), kg = num($('#iKg').value), tot = num($('#iVT').value);
      const common = { fecha: $('#iF').value || today(), hora: $('#iH').value, lote: $('#iL').value, producto: $('#iP').value.trim(), cantidad: $('#iQ').value, unidad: $('#iU').value, peso: $('#iKg').value, notas: $('#iN').value.trim(), ...getLoc() };
      let data;
      if (modo === 'rec') {
        if (!q && !kg) return toast('Escribe la cantidad o el peso recolectado', true);
        data = { ...common, tipo: 'Recolección', total: 0, recolector: $('#iRec').value, estado: '' };
      } else {
        if (!tot) return toast('Escribe el precio de la venta', true);
        data = { ...common, tipo: $('#iT').value, viaje: $('#iV').value.trim(), base, total: tot, precioKg: kg ? Math.round(tot / kg) : '', precioUnit: q ? Math.round(tot / q) : '', comprador: $('#iC').value.trim(), estado: $('#iE').value, vehiculo: $('#iVeh').value.trim(), conductor: $('#iCond').value.trim(), destino: $('#iDest').value.trim() };
      }
      try { i ? await Store.update('ingresos', i.id, data) : await Store.add('ingresos', data); toast(i ? 'Registro actualizado' : modo === 'rec' ? 'Recolección registrada 🧺' : 'Venta registrada 🚚'); Sheet.close(); render(); } catch (e) { toast(authError(e), true); }
    };
    if (i) $('#iX', b).onclick = async () => { if (await confirmBox('¿Eliminar este registro?')) { await Store.remove('ingresos', i.id); toast('Registro eliminado'); render(); } };
  });
};

Forms.evento = (e, preset = {}) => {
  const d = e || { fecha: preset.fecha || state.calSel || today(), tipo: 'fertilizacion', lote: preset.lote ?? (state.view === 'lote' ? state.params.id : ''), ...preset };
  Sheet.open(e ? 'Editar labor' : 'Programar labor', `
    <div class="field"><label>Tipo de labor</label><div class="chips" style="flex-wrap:wrap">${EVENT_TYPES.map(t => `<button class="chip ${t.id === d.tipo ? 'on' : ''}" data-t="${t.id}">${t.icon} ${t.name}</button>`).join('')}</div></div>
    <div class="field"><label>Título</label><input id="eT" value="${esc(d.titulo || '')}" placeholder="Ej: Abonada con triple 15"></div>
    <div class="grid2"><div class="field"><label>Fecha</label><input type="date" id="eF" value="${esc(d.fecha)}"></div><div class="field"><label>Hora</label><input type="time" id="eH" value="${esc(d.hora || '')}"></div></div>
    <div class="field"><label>Cultivo</label><select id="eL">${loteOptions(d.lote || '')}</select></div>
    ${!e ? `<div class="field"><label>Repetir</label><select id="eR"><option value="0">No repetir</option><option value="7">Cada semana</option><option value="15">Cada 15 días</option><option value="30">Cada mes</option><option value="60">Cada 2 meses</option><option value="90">Cada 3 meses</option></select><div class="hint">Se crean las próximas 8 fechas.</div></div>` : ''}
    <div class="field"><label>Notas</label><textarea id="eN" placeholder="Producto, dosis, responsable">${esc(d.notas || '')}</textarea></div>
    ${e ? `<label class="check" style="color:var(--text)"><input type="checkbox" id="eD" ${e.hecho ? 'checked' : ''}> Labor realizada</label>` : ''}
    <button class="btn primary block" id="eS">${e ? 'Guardar cambios' : 'Guardar labor'}</button>
    ${e ? '<button class="btn danger block" id="eX" style="margin-top:10px">Eliminar labor</button>' : ''}`, b => {
    let tipo = d.tipo;
    $$('[data-t]', b).forEach(x => x.onclick = () => { tipo = x.dataset.t; $$('[data-t]', b).forEach(y => y.classList.toggle('on', y === x)); });
    $('#eS', b).onclick = async () => {
      const base = { tipo, titulo: $('#eT').value.trim() || evType(tipo).name, fecha: $('#eF').value || today(), hora: $('#eH').value, lote: $('#eL').value, notas: $('#eN').value.trim() };
      try {
        if (e) await Store.update('eventos', e.id, { ...base, hecho: $('#eD').checked });
        else {
          const rep = num($('#eR').value); const grupo = rep ? Date.now().toString(36) : null;
          const n = rep ? 8 : 1;
          for (let k = 0; k < n; k++) { const dt = parseDate(base.fecha); if (rep === 30 || rep === 60 || rep === 90) dt.setMonth(dt.getMonth() + k * rep / 30); else dt.setDate(dt.getDate() + k * rep); await Store.add('eventos', { ...base, fecha: isoDate(dt), hecho: false, grupo }); }
        }
        toast(e ? 'Labor actualizada' : 'Labor programada 📅'); Sheet.close(); render();
      } catch (err) { toast(authError(err), true); }
    };
    if (e) $('#eX', b).onclick = async () => {
      const others = e.grupo ? Store.list('eventos').filter(x => x.grupo === e.grupo && x.id !== e.id && !x.hecho) : [];
      if (!await confirmBox(others.length ? `¿Eliminar esta labor y sus ${others.length} repeticiones pendientes?` : '¿Eliminar esta labor?')) return;
      await Store.remove('eventos', e.id); for (const o of others) await Store.remove('eventos', o.id);
      toast('Labor eliminada'); render();
    };
  });
};

Forms.nuevaFactura = async (kind) => {
  if (!kind) {
    Sheet.open('Nueva factura', `<div class="capture"><button id="nfC"><span class="e">📷</span>Escanear con cámara</button><button id="nfF"><span class="e">📎</span>Cargar archivo</button></div>`, b => {
      $('#nfC', b).onclick = () => Forms.nuevaFactura('camera'); $('#nfF', b).onclick = () => Forms.nuevaFactura('file');
    });
    return;
  }
  const f = await pickFile(kind); if (!f) return;
  Sheet.open('Procesando…', '<div class="empty"><div class="big">🧾</div><p>Preparando la factura…</p></div>');
  const adj = await fileToAttachment(f);
  if (!adj) { Sheet.close(); return; }
  Forms.factura(null, adj);
};

Forms.factura = (fx, newAttach) => {
  const isNew = !fx;
  const d = fx || { adjunto: newAttach, fecha: today(), categoria: 'insumos', lote: state.view === 'lote' ? state.params.id : '' };
  const a = d.adjunto;
  const gasto = fx?.gastoId ? Store.get('gastos', fx.gastoId) : null;
  Sheet.open(isNew ? 'Nueva factura' : 'Factura', `
    <div class="preview">${a?.tipo === 'imagen' && a.data ? `<img src="${a.data}" alt="Factura" id="fImg">` : a?.tipo === 'pdf' ? `<div class="pdf">📄 <b>${esc(a.nombre)}</b>${a.data ? '' : '<br><small>(archivo no guardado por tamaño)</small>'}</div>` : '<div class="pdf">Sin archivo adjunto</div>'}</div>
    ${a?.tipo === 'imagen' && a.data ? `<button class="btn block" id="fOcr" style="margin-bottom:8px">🔎 Leer factura automáticamente</button><div class="progress" id="fProg" hidden><i></i></div><div class="ocr-box" id="fTxt" hidden></div>` : ''}
    <div class="field"><label>Proveedor / almacén</label><input id="fP" value="${esc(d.proveedor || '')}"></div>
    <div class="grid2"><div class="field"><label>NIT</label><input id="fNit" value="${esc(d.nit || '')}"></div><div class="field"><label>N.º factura</label><input id="fN" value="${esc(d.numero || '')}"></div></div>
    <div class="grid2"><div class="field"><label>Fecha</label><input type="date" id="fF" value="${esc(d.fecha || today())}"></div><div class="field"><label>Total</label><input type="number" inputmode="numeric" id="fT" value="${esc(d.total || '')}" placeholder="$"></div></div>
    <div class="grid2"><div class="field"><label>Cultivo</label><select id="fL">${loteOptions(d.lote || '')}</select></div>
      <div class="field"><label>Tipo de gasto</label><select id="fC">${EXPENSE_CATEGORIES.map(c => `<option value="${c.id}" ${c.id === d.categoria ? 'selected' : ''}>${c.icon} ${c.name}</option>`).join('')}</select></div></div>
    <div class="field"><label>Detalle / productos</label><textarea id="fD" placeholder="Ej: 2 bultos de urea, 1 litro de glifosato">${esc(d.notas || '')}</textarea></div>
    ${isNew ? `<label class="check" style="color:var(--text)"><input type="checkbox" id="fG" checked> Registrar también como gasto</label>` : gasto ? `<div class="item" id="fOpenG">${'<div class="ic">💸</div>'}<div class="mid"><b>Gasto ligado</b><small>${esc(gasto.descripcion || gasto.tipo)} · ${money(gasto.total)}</small></div>${ICON.chevR}</div>` : ''}
    <button class="btn primary block" id="fS" style="margin-top:8px">${isNew ? 'Guardar factura' : 'Guardar cambios'}</button>
    ${!isNew && a?.data ? `<button class="btn block" id="fDl" style="margin-top:10px">${ICON.download} Descargar archivo</button>` : ''}
    ${!isNew ? '<button class="btn danger block" id="fX" style="margin-top:10px">Eliminar factura</button>' : ''}`, b => {
    if ($('#fOcr', b)) $('#fOcr', b).onclick = async () => {
      const btn = $('#fOcr'); btn.disabled = true; btn.textContent = 'Leyendo factura…'; $('#fProg').hidden = false;
      try {
        const T = await loadTesseract();
        const r = await T.recognize(a.data, 'spa', { logger: m => { if (m.status === 'recognizing text') $('#fProg i').style.width = Math.round(m.progress * 100) + '%'; } });
        const text = r.data.text || ''; const p = parseInvoiceText(text);
        $('#fTxt').hidden = false; $('#fTxt').textContent = text.trim() || '(no se reconoció texto)';
        if (p.proveedor && !$('#fP').value) $('#fP').value = p.proveedor;
        if (p.nit && !$('#fNit').value) $('#fNit').value = p.nit;
        if (p.numero && !$('#fN').value) $('#fN').value = p.numero;
        if (p.fecha) $('#fF').value = p.fecha;
        if (p.total && !$('#fT').value) $('#fT').value = p.total;
        btn.textContent = '✅ Revisa los datos detectados';
        toast(Object.keys(p).length ? 'Datos detectados, revísalos' : 'No se detectaron datos, escríbelos a mano');
      } catch (e) { btn.disabled = false; btn.textContent = '🔎 Leer factura automáticamente'; toast(e.message || 'No se pudo leer', true); }
      $('#fProg').hidden = true;
    };
    if ($('#fOpenG', b)) $('#fOpenG', b).onclick = () => Forms.gasto(gasto);
    if ($('#fDl', b)) $('#fDl', b).onclick = () => saveFile(a.tipo === 'pdf' ? (a.nombre || 'factura.pdf') : `factura_${(d.proveedor || 'terratech').replace(/\W+/g, '_')}_${d.fecha}.jpg`, a.data);
    $('#fS', b).onclick = async () => {
      const data = { adjunto: a || null, proveedor: $('#fP').value.trim(), nit: $('#fNit').value.trim(), numero: $('#fN').value.trim(), fecha: $('#fF').value || today(), total: num($('#fT').value), lote: $('#fL').value, categoria: $('#fC').value, notas: $('#fD').value.trim() };
      const btn = $('#fS'); btn.disabled = true; btn.textContent = 'Guardando…';
      try {
        if (isNew) {
          const f = await Store.add('facturas', data);
          if ($('#fG').checked && data.total) {
            const c = cat(data.categoria);
            const g = await Store.add('gastos', { fecha: data.fecha, lote: data.lote, categoria: data.categoria, tipo: c.subs[0], descripcion: data.notas.split('\n')[0].slice(0, 60) || `Factura ${data.numero || ''}`.trim(), total: data.total, proveedor: data.proveedor, metodo: 'Efectivo', estado: 'Pagado', facturaId: f.id, notas: data.numero ? `Factura N.º ${data.numero}` : '' });
            await Store.update('facturas', f.id, { gastoId: g.id });
            toast('Factura y gasto guardados ✅');
            Sheet.close(); render();
            setTimeout(() => Forms.gasto(Store.get('gastos', g.id)), 250);   // para completar cantidad y clase
            return;
          }
          toast('Factura guardada ✅');
        } else {
          await Store.update('facturas', fx.id, data);
          if (gasto) await Store.update('gastos', gasto.id, { total: data.total || gasto.total, proveedor: data.proveedor || gasto.proveedor, fecha: data.fecha, lote: data.lote, categoria: data.categoria });
          toast('Factura actualizada');
        }
        Sheet.close(); render();
      } catch (e) { btn.disabled = false; btn.textContent = 'Guardar factura'; toast(authError(e), true); }
    };
    if ($('#fX', b)) $('#fX', b).onclick = async () => {
      if (!await confirmBox('¿Eliminar esta factura? El gasto ligado se conserva.')) return;
      await Store.remove('facturas', fx.id); if (gasto) await Store.update('gastos', gasto.id, { facturaId: null });
      toast('Factura eliminada'); render();
    };
  });
};

Forms.pqr = () => {
  Sheet.open('Nueva PQR', `
    <div class="field"><label>Tipo de solicitud</label><div class="chips" style="flex-wrap:wrap">${PQR_TYPES.map((t, k) => `<button class="chip ${k === 0 ? 'on' : ''}" data-t="${t}">${t}</button>`).join('')}</div></div>
    <div class="field"><label>Asunto</label><input id="qA" placeholder="Resumen corto"></div>
    <div class="field"><label>Descripción</label><textarea id="qD" placeholder="Cuéntanos con detalle qué pasó o qué necesitas" style="min-height:130px"></textarea></div>
    <div class="field"><label>Correo para la respuesta</label><input id="qE" type="email" value="${esc(Store.user.email)}"></div>
    <div class="field"><label>Teléfono (opcional)</label><input id="qT" type="tel" value="${esc(Store.profile.telefono || '')}"></div>
    <label class="check" style="color:var(--text)"><input type="checkbox" id="qOk"> Autorizo el tratamiento de mis datos para responder esta solicitud (Ley 1581 de 2012).</label>
    <button class="btn primary block" id="qS">Radicar solicitud</button>`, b => {
    let tipo = PQR_TYPES[0];
    $$('[data-t]', b).forEach(x => x.onclick = () => { tipo = x.dataset.t; $$('[data-t]', b).forEach(y => y.classList.toggle('on', y === x)); });
    $('#qS', b).onclick = async () => {
      const asunto = $('#qA').value.trim(), desc = $('#qD').value.trim();
      if (!asunto || desc.length < 10) return toast('Escribe el asunto y una descripción', true);
      if (!$('#qOk').checked) return toast('Debes autorizar el tratamiento de datos', true);
      const d = new Date(); const radicado = `TT-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${Math.floor(1000 + Math.random() * 9000)}`;
      const p = await Store.add('pqr', { tipo, asunto, descripcion: desc, correo: $('#qE').value.trim(), telefono: $('#qT').value.trim(), radicado, fecha: today(), estado: 'Radicada', app: `${APP.name} ${APP.version}` });
      Forms.verPqr(p, true);
    };
  });
};

Forms.verPqr = (p, recien = false) => {
  const mail = `mailto:${APP.pqrEmail}?subject=${encodeURIComponent(`[TerraTech PQR ${p.radicado}] ${p.tipo}: ${p.asunto}`)}&body=${encodeURIComponent(`Radicado: ${p.radicado}\nTipo: ${p.tipo}\nFecha: ${p.fecha}\nUsuario: ${Store.user.name} <${p.correo}>\nTeléfono: ${p.telefono || '-'}\n\n${p.descripcion}`)}`;
  Sheet.open(recien ? '¡Solicitud radicada!' : p.tipo, `
    ${recien ? `<div class="empty" style="padding:8px 0 14px"><div class="big">✅</div><p>Tu número de radicado es</p><b style="font-size:20px" class="radicado">${esc(p.radicado)}</b></div>` : ''}
    <div class="total-box"><span>Estado</span><span class="tag ${p.estado === 'Respondida' ? '' : 'gold'}">${esc(p.estado)}</span></div>
    <p><b>${esc(p.asunto)}</b></p><p style="white-space:pre-wrap;color:var(--muted)">${esc(p.descripcion)}</p>
    <p class="radicado">${esc(p.radicado)} · ${fmtDate(p.fecha)} · ${esc(p.tipo)}</p>
    ${p.respuesta ? `<div class="banner info">💬 <div><b>Respuesta:</b><br>${esc(p.respuesta)}</div></div>` : ''}
    <a class="btn block" href="${mail}" style="text-decoration:none;margin-bottom:10px">📧 Enviar también por correo</a>
    <button class="btn primary block" id="vOk">Listo</button>`, b => { $('#vOk', b).onclick = () => { Sheet.close(); state.view === 'pqr' ? render() : go('pqr'); }; });
};

/* ---------------- Inicio de sesión ---------------- */
function renderAuth(tab = 'login') {
  const saved = Store.savedEmails.list();
  const el = $('#auth');
  el.innerHTML = `
    <img src="img/logo.png" alt="TerraTech" class="auth-logo">
    <div class="auth-brand brand-word"><span class="t1">Terra</span><span class="t2">Tech</span></div>
    <div class="auth-tag">Las cuentas claras de tu cultivo 🌱</div>
    <div class="auth-card">
      <div class="tabs-auth"><button data-tab="login" class="${tab === 'login' ? 'on' : ''}">Iniciar sesión</button><button data-tab="reg" class="${tab === 'reg' ? 'on' : ''}">Crear cuenta</button></div>
      ${tab === 'login' ? `
        ${saved.length ? `<div class="saved-emails">${saved.map(e => `<span class="chip-mail"><b data-use="${esc(e)}">${esc(e)}</b><button data-del="${esc(e)}" aria-label="Quitar">${ICON.x}</button></span>`).join('')}</div>` : ''}
        <form id="fLogin" autocomplete="on">
          <div class="field"><label>Correo electrónico</label><input id="aE" type="email" autocomplete="username" required value="${esc(saved[0] || '')}" placeholder="tucorreo@gmail.com"></div>
          <div class="field"><label>Contraseña</label><div class="pass-wrap"><input id="aP" type="password" autocomplete="current-password" required placeholder="••••••"><button type="button" class="eye" aria-label="Mostrar">${ICON.eye}</button></div></div>
          <label class="check"><input type="checkbox" id="aSave" checked> Guardar mi correo en este teléfono</label>
          <button class="btn primary block" type="submit" id="aGo">Entrar</button>
        </form>
        <div style="text-align:center;margin-top:8px"><button class="link-btn" id="aForgot">¿Olvidaste tu contraseña?</button></div>`
      : `
        <form id="fReg" autocomplete="on">
          <div class="field"><label>Nombre completo</label><input id="rN" required autocomplete="name" placeholder="Tu nombre"></div>
          <div class="field"><label>Correo electrónico</label><input id="rE" type="email" required autocomplete="email" placeholder="tucorreo@gmail.com"></div>
          <div class="field"><label>Contraseña</label><div class="pass-wrap"><input id="rP" type="password" required minlength="6" autocomplete="new-password" placeholder="Mínimo 6 caracteres"><button type="button" class="eye" aria-label="Mostrar">${ICON.eye}</button></div></div>
          <div class="field"><label>Confirmar contraseña</label><input id="rP2" type="password" required autocomplete="new-password"></div>
          <label class="check"><input type="checkbox" id="rSave" checked> Guardar mi correo en este teléfono</label>
          <label class="check"><input type="checkbox" id="rOk"> Acepto los términos de uso y el tratamiento de mis datos</label>
          <button class="btn primary block" type="submit" id="rGo">Crear mi cuenta</button>
        </form>`}
    </div>
    <div class="mode-note">${Store.mode === 'firebase' ? '☁️ Conectado al servidor: tu cuenta y tus datos se sincronizan en todos tus teléfonos.' : '📱 <b>Modo local:</b> la cuenta y los datos quedan en este teléfono. Configura el servidor para sincronizar.'}</div>
    <div class="copyright">${sealSVG('seal-mini')}${copyrightLine()}<br>TerraTech v${APP.version}</div>`;
  $$('[data-tab]', el).forEach(b => b.onclick = () => renderAuth(b.dataset.tab));
  $$('.eye', el).forEach(b => b.onclick = () => { const i = b.previousElementSibling; i.type = i.type === 'password' ? 'text' : 'password'; });
  $$('[data-use]', el).forEach(b => b.onclick = () => { $('#aE').value = b.dataset.use; $('#aP').focus(); });
  $$('[data-del]', el).forEach(b => b.onclick = () => { Store.savedEmails.remove(b.dataset.del); renderAuth('login'); });
  if (tab === 'login') {
    $('#fLogin').onsubmit = async (ev) => {
      ev.preventDefault(); const btn = $('#aGo'); btn.disabled = true; btn.textContent = 'Entrando…';
      const email = $('#aE').value.trim();
      try { await Store.login(email, $('#aP').value); if ($('#aSave')?.checked) Store.savedEmails.add(email); }
      catch (e) { toast(authError(e), true); btn.disabled = false; btn.textContent = 'Entrar'; }
    };
    $('#aForgot').onclick = async () => {
      const email = $('#aE').value.trim(); if (!email) return toast('Escribe tu correo primero', true);
      try { await Store.resetPassword(email); toast('Te enviamos un correo para cambiar la contraseña'); } catch (e) { toast(authError(e), true); }
    };
  } else {
    $('#fReg').onsubmit = async (ev) => {
      ev.preventDefault();
      const n = $('#rN').value.trim(), e = $('#rE').value.trim(), p = $('#rP').value;
      if (p !== $('#rP2').value) return toast('Las contraseñas no coinciden', true);
      if (p.length < 6) return toast('La contraseña debe tener al menos 6 caracteres', true);
      if (!$('#rOk').checked) return toast('Debes aceptar los términos', true);
      const btn = $('#rGo'); btn.disabled = true; btn.textContent = 'Creando cuenta…';
      try { await Store.register(n, e, p); if ($('#rSave').checked) Store.savedEmails.add(e); toast('¡Bienvenido a TerraTech! 🌱'); }
      catch (err) { toast(authError(err), true); btn.disabled = false; btn.textContent = 'Crear mi cuenta'; }
    };
  }
}

/* ---------------- Tema ---------------- */
function setTheme(t) {
  try { localStorage.setItem('tt_theme', t); } catch {}
  if (t === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', t);
}

/* ---------------- Arranque ---------------- */
async function boot() {
  setTheme(localStorage.getItem('tt_theme') || 'auto');
  $('#btnBack').onclick = () => history.back();
  $('#btnMenu').onclick = () => go('mas');
  $('#sheetClose').onclick = Sheet.close;
  $('.sheet-backdrop').onclick = Sheet.close;
  $$('#bottomnav button').forEach(b => b.onclick = () => go(b.dataset.go));
  $('#fab').onclick = () => {
    const v = state.view;
    if (v === 'cultivos' || v === 'catalogo') return v === 'catalogo' ? Forms.cultivoPropio() : Forms.lote();
    if (v === 'gastos' || v === 'lote') return Forms.gasto();
    if (v === 'ingresos') return Forms.ingreso();
    if (v === 'facturas') return Forms.nuevaFactura();
    if (v === 'calendario') return Forms.evento(null, { fecha: state.calSel });
    if (v === 'pqr') return Forms.pqr();
    if (v === 'trabajadores') return Forms.trabajo();
    if (v === 'trabajador') return Forms.trabajo(null, { trabajador: state.params.id });
    Sheet.open('¿Qué deseas registrar?', `<div class="menu-grid">
      <button class="menu-tile" data-a="g"><span class="e">🧾</span><b>Gasto</b><small>Insumos, jornales…</small></button>
      <button class="menu-tile" data-a="i"><span class="e">🚚</span><b>Carga / venta</b><small>Peso y precio</small></button>
      <button class="menu-tile" data-a="j"><span class="e">📝</span><b>Jornal / trabajo</b><small>Trabajadores</small></button>
      <button class="menu-tile" data-a="p"><span class="e">💵</span><b>Pago</b><small>A trabajador</small></button>
      <button class="menu-tile" data-a="f"><span class="e">📷</span><b>Factura</b><small>Escanear o cargar</small></button>
      <button class="menu-tile" data-a="e"><span class="e">📅</span><b>Labor</b><small>Calendario</small></button>
      <button class="menu-tile" data-a="l"><span class="e">🌱</span><b>Cultivo</b><small>Nuevo lote</small></button></div>`, b => {
      $$('[data-a]', b).forEach(x => x.onclick = () => ({ g: () => Forms.gasto(), i: () => Forms.ingreso(), f: () => Forms.nuevaFactura(), e: () => Forms.evento(), l: () => Forms.lote(), j: () => Forms.trabajo(), p: () => Forms.pago() }[x.dataset.a])());
    });
  };

  let first = true;
  Store.subscribe(() => { if (Store.user && !$('#app').hidden && $('#sheetWrap').hidden) render(); });
  Store.onUser((u) => {
    $('#splash').hidden = true;
    if (u) {
      $('#auth').hidden = true; $('#app').hidden = false;
      if (first) { history.replaceState({ view: 'inicio', params: {} }, ''); first = false; }
      state.view = 'inicio'; render();
    } else {
      Sheet.close(); $('#app').hidden = true; $('#auth').hidden = false; renderAuth('login');
    }
  });
  await Store.init();
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else setTimeout(boot, 0);
