/* TerraTech — catálogos base
   © 2026 Juan Diego Pérez Lopez. Todos los derechos reservados. */

const CROP_GROUPS = [
  { id: 'musaceas', name: 'Musáceas' },
  { id: 'cereales', name: 'Cereales y granos' },
  { id: 'frutales', name: 'Frutales' },
  { id: 'pasifloras', name: 'Pasifloras' },
  { id: 'tuberculos', name: 'Tubérculos y raíces' },
  { id: 'hortalizas', name: 'Hortalizas' },
  { id: 'leguminosas', name: 'Leguminosas' },
  { id: 'industriales', name: 'Industriales y permanentes' },
  { id: 'aromaticas', name: 'Aromáticas y especias' },
  { id: 'forrajes', name: 'Pastos y forrajes' },
  { id: 'otros', name: 'Otros' }
];

// icono = emoji, unidad = unidad típica de cosecha
const CROPS = [
  // Musáceas
  { id: 'platano', name: 'Plátano', group: 'musaceas', icon: '🍌', unit: 'racimo' },
  { id: 'banano', name: 'Banano', group: 'musaceas', icon: '🍌', unit: 'caja' },
  { id: 'guineo', name: 'Guineo / Bocadillo', group: 'musaceas', icon: '🍌', unit: 'racimo' },
  // Cereales
  { id: 'maiz', name: 'Maíz', group: 'cereales', icon: '🌽', unit: 'bulto' },
  { id: 'maiz-choclo', name: 'Maíz choclo / mazorca', group: 'cereales', icon: '🌽', unit: 'docena' },
  { id: 'arroz', name: 'Arroz', group: 'cereales', icon: '🌾', unit: 'carga' },
  { id: 'sorgo', name: 'Sorgo', group: 'cereales', icon: '🌾', unit: 'ton' },
  { id: 'trigo', name: 'Trigo', group: 'cereales', icon: '🌾', unit: 'bulto' },
  { id: 'cebada', name: 'Cebada', group: 'cereales', icon: '🌾', unit: 'bulto' },
  { id: 'avena', name: 'Avena', group: 'cereales', icon: '🌾', unit: 'bulto' },
  { id: 'quinua', name: 'Quinua', group: 'cereales', icon: '🌾', unit: 'kg' },
  // Frutales
  { id: 'aguacate', name: 'Aguacate', group: 'frutales', icon: '🥑', unit: 'kg' },
  { id: 'aguacate-hass', name: 'Aguacate Hass', group: 'frutales', icon: '🥑', unit: 'kg' },
  { id: 'mango', name: 'Mango', group: 'frutales', icon: '🥭', unit: 'kg' },
  { id: 'naranja', name: 'Naranja', group: 'frutales', icon: '🍊', unit: 'bulto' },
  { id: 'mandarina', name: 'Mandarina', group: 'frutales', icon: '🍊', unit: 'kg' },
  { id: 'limon', name: 'Limón', group: 'frutales', icon: '🍋', unit: 'kg' },
  { id: 'pina', name: 'Piña', group: 'frutales', icon: '🍍', unit: 'unidad' },
  { id: 'papaya', name: 'Papaya', group: 'frutales', icon: '🍈', unit: 'kg' },
  { id: 'fresa', name: 'Fresa', group: 'frutales', icon: '🍓', unit: 'kg' },
  { id: 'mora', name: 'Mora', group: 'frutales', icon: '🫐', unit: 'kg' },
  { id: 'lulo', name: 'Lulo', group: 'frutales', icon: '🟠', unit: 'kg' },
  { id: 'tomate-arbol', name: 'Tomate de árbol', group: 'frutales', icon: '🍅', unit: 'kg' },
  { id: 'uchuva', name: 'Uchuva', group: 'frutales', icon: '🟡', unit: 'kg' },
  { id: 'guayaba', name: 'Guayaba', group: 'frutales', icon: '🍐', unit: 'kg' },
  { id: 'guanabana', name: 'Guanábana', group: 'frutales', icon: '🍈', unit: 'kg' },
  { id: 'feijoa', name: 'Feijoa', group: 'frutales', icon: '🍐', unit: 'kg' },
  { id: 'sandia', name: 'Sandía', group: 'frutales', icon: '🍉', unit: 'unidad' },
  { id: 'melon', name: 'Melón', group: 'frutales', icon: '🍈', unit: 'unidad' },
  { id: 'uva', name: 'Uva', group: 'frutales', icon: '🍇', unit: 'kg' },
  { id: 'durazno', name: 'Durazno', group: 'frutales', icon: '🍑', unit: 'kg' },
  { id: 'manzana', name: 'Manzana', group: 'frutales', icon: '🍎', unit: 'kg' },
  { id: 'pera', name: 'Pera', group: 'frutales', icon: '🍐', unit: 'kg' },
  { id: 'coco', name: 'Coco', group: 'frutales', icon: '🥥', unit: 'unidad' },
  { id: 'pitahaya', name: 'Pitahaya', group: 'frutales', icon: '🐉', unit: 'kg' },
  { id: 'arandano', name: 'Arándano', group: 'frutales', icon: '🫐', unit: 'kg' },
  // Pasifloras
  { id: 'maracuya', name: 'Maracuyá', group: 'pasifloras', icon: '💛', unit: 'kg' },
  { id: 'granadilla', name: 'Granadilla', group: 'pasifloras', icon: '🟠', unit: 'kg' },
  { id: 'gulupa', name: 'Gulupa', group: 'pasifloras', icon: '🟣', unit: 'kg' },
  { id: 'curuba', name: 'Curuba', group: 'pasifloras', icon: '🟡', unit: 'kg' },
  { id: 'badea', name: 'Badea', group: 'pasifloras', icon: '🟢', unit: 'kg' },
  // Tubérculos
  { id: 'papa', name: 'Papa', group: 'tuberculos', icon: '🥔', unit: 'bulto' },
  { id: 'papa-criolla', name: 'Papa criolla', group: 'tuberculos', icon: '🥔', unit: 'bulto' },
  { id: 'yuca', name: 'Yuca', group: 'tuberculos', icon: '🍠', unit: 'bulto' },
  { id: 'name', name: 'Ñame', group: 'tuberculos', icon: '🍠', unit: 'bulto' },
  { id: 'arracacha', name: 'Arracacha', group: 'tuberculos', icon: '🥕', unit: 'bulto' },
  { id: 'batata', name: 'Batata', group: 'tuberculos', icon: '🍠', unit: 'kg' },
  { id: 'malanga', name: 'Malanga / Bore', group: 'tuberculos', icon: '🍠', unit: 'kg' },
  { id: 'jengibre', name: 'Jengibre', group: 'tuberculos', icon: '🫚', unit: 'kg' },
  // Hortalizas
  { id: 'tomate', name: 'Tomate', group: 'hortalizas', icon: '🍅', unit: 'canastilla' },
  { id: 'cebolla-cabezona', name: 'Cebolla cabezona', group: 'hortalizas', icon: '🧅', unit: 'bulto' },
  { id: 'cebolla-larga', name: 'Cebolla larga', group: 'hortalizas', icon: '🧅', unit: 'arroba' },
  { id: 'zanahoria', name: 'Zanahoria', group: 'hortalizas', icon: '🥕', unit: 'bulto' },
  { id: 'lechuga', name: 'Lechuga', group: 'hortalizas', icon: '🥬', unit: 'unidad' },
  { id: 'repollo', name: 'Repollo', group: 'hortalizas', icon: '🥬', unit: 'unidad' },
  { id: 'brocoli', name: 'Brócoli', group: 'hortalizas', icon: '🥦', unit: 'kg' },
  { id: 'coliflor', name: 'Coliflor', group: 'hortalizas', icon: '🥦', unit: 'kg' },
  { id: 'pimenton', name: 'Pimentón', group: 'hortalizas', icon: '🫑', unit: 'kg' },
  { id: 'aji', name: 'Ají', group: 'hortalizas', icon: '🌶️', unit: 'kg' },
  { id: 'pepino', name: 'Pepino', group: 'hortalizas', icon: '🥒', unit: 'kg' },
  { id: 'ahuyama', name: 'Ahuyama / Zapallo', group: 'hortalizas', icon: '🎃', unit: 'unidad' },
  { id: 'calabacin', name: 'Calabacín', group: 'hortalizas', icon: '🥒', unit: 'kg' },
  { id: 'berenjena', name: 'Berenjena', group: 'hortalizas', icon: '🍆', unit: 'kg' },
  { id: 'espinaca', name: 'Espinaca', group: 'hortalizas', icon: '🥬', unit: 'kg' },
  { id: 'remolacha', name: 'Remolacha', group: 'hortalizas', icon: '🟣', unit: 'kg' },
  { id: 'ajo', name: 'Ajo', group: 'hortalizas', icon: '🧄', unit: 'kg' },
  { id: 'apio', name: 'Apio', group: 'hortalizas', icon: '🥬', unit: 'atado' },
  // Leguminosas
  { id: 'frijol', name: 'Fríjol', group: 'leguminosas', icon: '🫘', unit: 'bulto' },
  { id: 'arveja', name: 'Arveja', group: 'leguminosas', icon: '🫛', unit: 'bulto' },
  { id: 'habichuela', name: 'Habichuela', group: 'leguminosas', icon: '🫛', unit: 'kg' },
  { id: 'haba', name: 'Haba', group: 'leguminosas', icon: '🫛', unit: 'bulto' },
  { id: 'soya', name: 'Soya', group: 'leguminosas', icon: '🫘', unit: 'ton' },
  { id: 'garbanzo', name: 'Garbanzo', group: 'leguminosas', icon: '🫘', unit: 'kg' },
  { id: 'mani', name: 'Maní', group: 'leguminosas', icon: '🥜', unit: 'kg' },
  // Industriales
  { id: 'cafe', name: 'Café', group: 'industriales', icon: '☕', unit: 'arroba' },
  { id: 'cacao', name: 'Cacao', group: 'industriales', icon: '🍫', unit: 'kg' },
  { id: 'cana-panelera', name: 'Caña panelera', group: 'industriales', icon: '🎋', unit: 'ton' },
  { id: 'cana-azucar', name: 'Caña de azúcar', group: 'industriales', icon: '🎋', unit: 'ton' },
  { id: 'palma', name: 'Palma de aceite', group: 'industriales', icon: '🌴', unit: 'ton' },
  { id: 'algodon', name: 'Algodón', group: 'industriales', icon: '☁️', unit: 'kg' },
  { id: 'tabaco', name: 'Tabaco', group: 'industriales', icon: '🍂', unit: 'kg' },
  { id: 'caucho', name: 'Caucho', group: 'industriales', icon: '🌳', unit: 'kg' },
  { id: 'fique', name: 'Fique', group: 'industriales', icon: '🌿', unit: 'kg' },
  { id: 'flores', name: 'Flores', group: 'industriales', icon: '🌸', unit: 'tallo' },
  { id: 'forestal', name: 'Forestal / Madera', group: 'industriales', icon: '🌲', unit: 'm3' },
  // Aromáticas
  { id: 'cilantro', name: 'Cilantro', group: 'aromaticas', icon: '🌿', unit: 'atado' },
  { id: 'albahaca', name: 'Albahaca', group: 'aromaticas', icon: '🌿', unit: 'kg' },
  { id: 'hierbabuena', name: 'Hierbabuena', group: 'aromaticas', icon: '🌱', unit: 'atado' },
  { id: 'oregano', name: 'Orégano', group: 'aromaticas', icon: '🌿', unit: 'kg' },
  { id: 'romero', name: 'Romero', group: 'aromaticas', icon: '🌿', unit: 'kg' },
  { id: 'tomillo', name: 'Tomillo', group: 'aromaticas', icon: '🌿', unit: 'kg' },
  { id: 'cebollin', name: 'Cebollín', group: 'aromaticas', icon: '🌱', unit: 'atado' },
  { id: 'stevia', name: 'Stevia', group: 'aromaticas', icon: '🌱', unit: 'kg' },
  // Forrajes
  { id: 'pasto', name: 'Pasto de corte', group: 'forrajes', icon: '🌾', unit: 'ton' },
  { id: 'pradera', name: 'Pradera / Potrero', group: 'forrajes', icon: '🐄', unit: 'ha' },
  { id: 'maiz-forrajero', name: 'Maíz forrajero / Ensilaje', group: 'forrajes', icon: '🌽', unit: 'ton' },
  { id: 'alfalfa', name: 'Alfalfa', group: 'forrajes', icon: '🌱', unit: 'paca' },
  // Otros
  { id: 'otro', name: 'Otro cultivo', group: 'otros', icon: '🌱', unit: 'kg' }
];

// Categorías de gasto → subtipos y unidades sugeridas
const EXPENSE_CATEGORIES = [
  { id: 'insumos', name: 'Insumos', icon: '🧪', color: '#1E8E3E',
    subs: ['Fertilizante químico', 'Abono orgánico / compost', 'Cal / enmiendas', 'Herbicida', 'Fungicida', 'Insecticida', 'Coadyuvante', 'Bioinsumo', 'Foliar / micronutrientes', 'Hormonas / enraizador'],
    units: ['bulto', 'kg', 'litro', 'galón', 'cc', 'gramo', 'unidad'] },
  { id: 'semillas', name: 'Semillas y material vegetal', icon: '🌱', color: '#6CC24A',
    subs: ['Semilla', 'Colinos / hijuelos', 'Plántulas', 'Injertos', 'Esquejes / estacas', 'Bulbos / tubérculo semilla'],
    units: ['kg', 'bulto', 'unidad', 'bandeja', 'gramo'] },
  { id: 'mano-obra', name: 'Mano de obra', icon: '👨‍🌾', color: '#8C5A2B',
    subs: ['Jornal', 'Contrato / al destajo', 'Cosecha / recolección', 'Fumigación', 'Siembra', 'Desyerba / limpieza', 'Poda / deshoje', 'Administrador / mayordomo'],
    units: ['jornal', 'hora', 'contrato', 'día', 'mes'] },
  { id: 'maquinaria', name: 'Maquinaria y equipo', icon: '🚜', color: '#0B5A2E',
    subs: ['Alquiler de tractor', 'Arada / rastrillada', 'Combustible', 'Guadaña', 'Bomba de espalda', 'Reparación de equipos', 'Lubricantes'],
    units: ['hora', 'galón', 'litro', 'servicio', 'día', 'unidad'] },
  { id: 'riego', name: 'Riego y servicios', icon: '💧', color: '#1F7AB8',
    subs: ['Agua / concesión', 'Energía eléctrica', 'Mangueras / cintas de goteo', 'Motobomba', 'Reservorio'],
    units: ['m3', 'kWh', 'metro', 'mes', 'unidad'] },
  { id: 'herramientas', name: 'Herramientas y materiales', icon: '🛠️', color: '#5A6B3A',
    subs: ['Machete / pala / azadón', 'Alambre / postes', 'Plástico / polisombra', 'Tutores / guaduas', 'Fibra / cabuya', 'Bolsas de vivero'],
    units: ['unidad', 'rollo', 'metro', 'kg', 'docena'] },
  { id: 'empaques', name: 'Empaques y poscosecha', icon: '📦', color: '#B07A2A',
    subs: ['Canastillas', 'Cajas', 'Costales / lonas', 'Bolsas', 'Etiquetas', 'Lavado / clasificación'],
    units: ['unidad', 'paquete', 'ciento', 'docena'] },
  { id: 'transporte', name: 'Transporte y fletes', icon: '🚚', color: '#7A4A1E',
    subs: ['Flete de cosecha', 'Flete de insumos', 'Mula / arriero', 'Peajes', 'Combustible vehículo'],
    units: ['viaje', 'bulto', 'km', 'galón', 'carga'] },
  { id: 'tierra', name: 'Tierra y arriendo', icon: '🏞️', color: '#4F7A28',
    subs: ['Arriendo', 'Impuesto predial', 'Adecuación del terreno', 'Cercas y caminos'],
    units: ['mes', 'año', 'ha', 'unidad'] },
  { id: 'tecnica', name: 'Asistencia técnica', icon: '📋', color: '#2E8B6E',
    subs: ['Agrónomo', 'Análisis de suelo', 'Análisis foliar', 'Certificaciones (ICA, BPA)', 'Capacitación'],
    units: ['visita', 'servicio', 'unidad', 'mes'] },
  { id: 'financieros', name: 'Gastos financieros', icon: '🏦', color: '#556B2F',
    subs: ['Intereses de crédito', 'Seguro agrícola', 'Comisiones bancarias'],
    units: ['mes', 'unidad'] },
  { id: 'otros', name: 'Otros gastos', icon: '🧾', color: '#7D8C7A',
    subs: ['Alimentación de trabajadores', 'Imprevistos', 'Otro'],
    units: ['unidad', 'servicio', 'día'] }
];

const INCOME_TYPES = ['Venta de cosecha', 'Venta de subproductos', 'Subsidio / apoyo', 'Alquiler de equipo', 'Otro ingreso'];

const HARVEST_UNITS = ['kg', 'arroba', 'bulto', 'carga', 'ton', 'racimo', 'caja', 'canastilla', 'unidad', 'docena', 'atado', 'tallo', 'paca', 'litro', 'm3'];

const EVENT_TYPES = [
  { id: 'siembra', name: 'Siembra', icon: '🌱', color: '#6CC24A' },
  { id: 'fertilizacion', name: 'Fertilización', icon: '🧪', color: '#1E8E3E' },
  { id: 'fumigacion', name: 'Fumigación', icon: '💨', color: '#2E8B6E' },
  { id: 'riego', name: 'Riego', icon: '💧', color: '#1F7AB8' },
  { id: 'desyerba', name: 'Desyerba / limpieza', icon: '🌿', color: '#4F7A28' },
  { id: 'poda', name: 'Poda / deshoje', icon: '✂️', color: '#5A6B3A' },
  { id: 'cosecha', name: 'Cosecha', icon: '🧺', color: '#B07A2A' },
  { id: 'venta', name: 'Venta / entrega', icon: '💰', color: '#C9A227' },
  { id: 'compra', name: 'Compra de insumos', icon: '🛒', color: '#8C5A2B' },
  { id: 'pago', name: 'Pago pendiente', icon: '📅', color: '#C0392B' },
  { id: 'recordatorio', name: 'Recordatorio', icon: '🔔', color: '#7D8C7A' }
];

const PAY_METHODS = ['Efectivo', 'Transferencia', 'Nequi / Daviplata', 'Tarjeta', 'Crédito / fiado', 'Otro'];
const PQR_TYPES = ['Petición', 'Queja', 'Reclamo', 'Sugerencia', 'Felicitación'];
const LOT_STATES = ['Preparación', 'Sembrado', 'En crecimiento', 'En producción', 'En cosecha', 'Finalizado'];

// Trabajadores
const WORKER_PAY_TYPES = ['Jornal', 'Destajo por kg', 'Destajo por unidad', 'Por hora', 'Contrato', 'Mensual'];
const WORK_UNITS = ['jornal', 'medio jornal', 'hora', 'día', 'kg', 'arroba', 'bulto', 'canastilla', 'racimo', 'unidad', 'contrato', 'mes'];
const WORK_LABORS = ['Desyerba / limpieza', 'Fumigación', 'Fertilización / abonada', 'Siembra', 'Cosecha / recolección', 'Poda / deshoje', 'Riego', 'Empaque / selección', 'Cargue', 'Preparación de tierra', 'Mantenimiento', 'Administración', 'Otra'];
const PAY_CONCEPTS = ['Pago de jornales', 'Adelanto', 'Liquidación', 'Bonificación'];
const SALE_BASES = [{ id: 'kg', name: 'Precio por kg' }, { id: 'unidad', name: 'Precio por empaque/unidad' }, { id: 'total', name: 'Valor total de la carga' }];
const PACK_UNITS = ['bulto', 'canastilla', 'racimo', 'caja', 'costal', 'arroba', 'carga', 'kg', 'ton', 'unidad', 'docena', 'atado', 'tallo', 'paca'];
