# TerraTech — Cuentas del campo

App para llevar las cuentas de cultivos (plátano, maíz, maracuyá, café y 100+ más).
© 2026 Juan Diego Pérez Lopez. Todos los derechos reservados.

## Qué trae
- **Inicio de sesión** con correo y contraseña, crear cuenta, recuperar contraseña y **correos guardados** en el teléfono.
- **Cultivos / lotes**: catálogo de 100+ cultivos por grupos + cultivos personalizados; área, plantas, fechas de siembra y cosecha, estado.
- **Gastos** clasificados por tipo (Insumos, Semillas, Mano de obra, Maquinaria, Riego, Herramientas, Empaques, Transporte, Tierra, Asistencia técnica, Financieros, Otros) con clase, **cantidad y unidad** (bulto, kg, litro, jornal…), valor unitario y total, proveedor y estado (pagado / pendiente).
- **Facturas**: escanear con la cámara o cargar foto/PDF, lectura automática (OCR) de proveedor, NIT, número, fecha y total; se ligan al gasto.
- **Cargas y ventas**: n.º de viaje, empaques, peso en kg, precio por kg, por empaque o total de la carga, comprador, vehículo y destino. **Recolección** con peso y quién recogió.
- **Trabajadores**: jornales y destajos, pagos con saldo (debe / a favor), adelantos, bonificaciones y comprobante de pago.
- **Fecha, hora y ubicación GPS** en pagos, cargas, recolecciones y trabajos, con enlace al mapa.
- **Informe detallado por día**: al tocar un día del calendario (y en Informes → Día), con línea de tiempo, trabajadores, cosecha, insumos y botón para compartir.
- **Calendario** de labores (siembra, fertilización, fumigación, riego, cosecha…) con repeticiones, más gastos e ingresos por día.
- **Informes**: balance, margen, gastos por tipo, por cultivo, últimos 12 meses, **cantidades utilizadas por tipo**, pendientes y exportación CSV.
- **PQR** con número de radicado (y envío por correo).
- **Derechos de autor** con sello y firma; perfil de finca, tema claro/oscuro y respaldo JSON.

## Servidor (Firebase) — para tener la misma cuenta en varios teléfonos
1. https://console.firebase.google.com → crear proyecto **terratech** (o usar uno existente).
2. Agregar app **Web** (`</>`) y copiar la configuración en `www/js/firebase-config.js`.
3. **Authentication → Método de acceso → Correo/contraseña → Habilitar**.
4. **Firestore Database → Crear base de datos**, y en **Reglas** pegar el contenido de `firestore.rules`.
5. Las PQR quedan en la colección `pqr` (y en la de cada usuario). Para responder, edita el documento y llena `respuesta` y `estado: "Respondida"`.

Sin configurar Firebase la app funciona en **modo local** (datos solo en ese teléfono).

## Generar el APK con GitHub Actions
1. Crea un repositorio (p. ej. `TerraTech`) y sube el contenido de esta carpeta (o el zip: el flujo lo descomprime solo).
2. Pestaña **Actions → Construir APK TerraTech** (corre al subir, o con *Run workflow*).
3. Al terminar, descarga **TerraTech-APK** en la sección *Artifacts*.

## Probar en el computador
`npx http-server www` o abrir `www/index.html` con un servidor local.
